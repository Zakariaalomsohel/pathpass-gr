package com.example

import com.example.calculator.ElevationService
import com.example.calculator.GeodeticCalculator
import com.example.calculator.MilitaryGridCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testUserScreenshotPoint2() {
        // Point 2: lat: 24.582254, lon: 90.141237
        // Screenshot displays:
        // GR: 146184
        // Map Sheet: 78 L/2
        val result = MilitaryGridCalculator.calculate(24.582254, 90.141237)
        assertEquals("146184", result.gr6)
        assertEquals("78 L/2", result.mapSheet50k)
        assertTrue(result.isWithinBangladesh)
        assertTrue("Elevation should be calculated", result.elevationInfo.elevationMeters > 0)
    }

    @Test
    fun testPoint1() {
        // Point 1: GR-004089 (78L/3) lat:24.4961502, Long:90.0014501
        val result = MilitaryGridCalculator.calculate(24.4961502, 90.0014501)
        assertEquals("004089", result.gr6)
        assertEquals("78 L/3", result.mapSheet50k)
    }

    @Test
    fun testMapSheetsForPoints() {
        val p4 = MilitaryGridCalculator.calculate(24.6374623, 89.9737190)
        assertEquals("78 H/14", p4.mapSheet50k)

        val p5 = MilitaryGridCalculator.calculate(24.511492, 90.3395672)
        assertEquals("78 L/6", p5.mapSheet50k)

        val p8 = MilitaryGridCalculator.calculate(24.7963661, 89.989117)
        assertEquals("78 H/13", p8.mapSheet50k)
    }

    @Test
    fun testReverseCalculationFromSheetAndGr() {
        // Reverse calculation: Sheet 78 L/2, GR 146184 -> Lat: ~24.582, Lon: ~90.141
        val reverse = MilitaryGridCalculator.reverseCalculate("78 L/2", "146184")
        assertNotNull(reverse)
        reverse!!

        // Verify latitude and longitude are within the 100m grid square
        val dist = GeodeticCalculator.calculateHaversineDistance(
            24.582254, 90.141237, reverse.wgsLat, reverse.wgsLon
        )
        assertTrue("Recovered point should be within 100m of original: $dist m", dist <= 100.0)
        assertEquals("78 L/2", reverse.mapSheet50k)
        assertEquals("146184", reverse.grInput)
        assertTrue(reverse.isWithinBangladesh)
        assertTrue("Elevation must be positive", reverse.elevationInfo.elevationMeters > 0)

        // CRITICAL USER REQUIREMENT: Exact roundtrip using forward formula!
        // calculate(reverse.wgsLat, reverse.wgsLon) must return exact input GR and Map Sheet!
        val forwardCheck = MilitaryGridCalculator.calculate(reverse.wgsLat, reverse.wgsLon)
        assertEquals("Forward GR must match input GR exactly", "146184", forwardCheck.gr6)
        assertEquals("Forward Map Sheet must match input Map Sheet exactly", "78 L/2", forwardCheck.mapSheet50k)
        assertTrue("isExactMatch must be true", reverse.isExactMatch)
    }

    @Test
    fun testMultiplePointsRoundTrip() {
        // Point 1: 78 L/3, GR 004089
        val p1Forward = MilitaryGridCalculator.calculate(24.4961502, 90.0014501)
        val p1Reverse = MilitaryGridCalculator.reverseCalculate(p1Forward.mapSheet50k, p1Forward.gr6)
        assertNotNull(p1Reverse)
        val p1Roundtrip = MilitaryGridCalculator.calculate(p1Reverse!!.wgsLat, p1Reverse.wgsLon)
        assertEquals(p1Forward.gr6, p1Roundtrip.gr6)
        assertEquals(p1Forward.mapSheet50k, p1Roundtrip.mapSheet50k)

        // Point 4: 78 H/14, 24.6374623, 89.9737190
        val p4Forward = MilitaryGridCalculator.calculate(24.6374623, 89.9737190)
        val p4Reverse = MilitaryGridCalculator.reverseCalculate(p4Forward.mapSheet50k, p4Forward.gr6)
        assertNotNull(p4Reverse)
        val p4Roundtrip = MilitaryGridCalculator.calculate(p4Reverse!!.wgsLat, p4Reverse.wgsLon)
        assertEquals(p4Forward.gr6, p4Roundtrip.gr6)
        assertEquals(p4Forward.mapSheet50k, p4Roundtrip.mapSheet50k)

        // Point 8: 78 H/13, 24.7963661, 89.989117
        val p8Forward = MilitaryGridCalculator.calculate(24.7963661, 89.989117)
        val p8Reverse = MilitaryGridCalculator.reverseCalculate(p8Forward.mapSheet50k, p8Forward.gr6)
        assertNotNull(p8Reverse)
        val p8Roundtrip = MilitaryGridCalculator.calculate(p8Reverse!!.wgsLat, p8Reverse.wgsLon)
        assertEquals(p8Forward.gr6, p8Roundtrip.gr6)
        assertEquals(p8Forward.mapSheet50k, p8Roundtrip.mapSheet50k)
    }

    @Test
    fun testElevationService() {
        // Coastal location (Sundarbans / Khulna): 0 - 5 meters
        val coastal = ElevationService.getLocalTopographicElevation(22.0, 89.5)
        assertTrue("Coastal elevation should be low (1-5m)", coastal.elevationMeters in 0.5..6.0)

        // Madhupur tract (Tangail): 15 - 30 meters
        val madhupur = ElevationService.getLocalTopographicElevation(24.582254, 90.141237)
        assertTrue("Madhupur elevation should be 15-30m", madhupur.elevationMeters in 15.0..32.0)

        // Chittagong Hill Tracts (Bandarban): > 80 meters
        val cht = ElevationService.getLocalTopographicElevation(22.0, 92.3)
        assertTrue("Hill tracts elevation should be > 80m", cht.elevationMeters > 80.0)
    }

    @Test
    fun testGeodeticCalculation() {
        val dhakaLat = 23.8103
        val dhakaLon = 90.4125
        val boguraLat = 24.8465
        val boguraLon = 89.3777

        val dist = GeodeticCalculator.calculateHaversineDistance(dhakaLat, dhakaLon, boguraLat, boguraLon)
        val bearing = GeodeticCalculator.calculateBearing(dhakaLat, dhakaLon, boguraLat, boguraLon)

        assertTrue("Distance should be approx 154-156 km", dist in 150000.0..160000.0)
        assertTrue("Bearing should be approx 310°-325°", bearing in 310.0..325.0)
    }
}
