package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Colorful Tactical Palette
val NeonGreen = Color(0xFF00E676)
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)

val ElectricCyan = Color(0xFF00E5FF)
val CyanPrimary = Color(0xFF06B6D4)
val CyanDark = Color(0xFF0E7490)

val SunsetOrange = Color(0xFFFF6D00)
val CoralAccent = Color(0xFFFF5252)

val CyberGold = Color(0xFFFFD600)
val AmberAccent = Color(0xFFF59E0B)

val RoyalPurple = Color(0xFF8B5CF6)
val DeepViolet = Color(0xFF7C3AED)

val TacticalNavyDark = Color(0xFF0B132B)
val TacticalCardDark = Color(0xFF1C2541)
val TacticalSurfaceDark = Color(0xFF141E33)
val TacticalBorderGlow = Color(0xFF3A506B)

// Light / Colorful Day Scheme
val VibrantBgLight = Color(0xFFF0FDF4)
val VibrantCardLight = Color(0xFFFFFFFF)
val VibrantBorderLight = Color(0xFFCBD5E1)
val VibrantTextPrimary = Color(0xFF0F172A)
val VibrantTextSecondary = Color(0xFF475569)

// Action button gradient colors
val BtnShowGrGrad1 = Color(0xFF059669)
val BtnShowGrGrad2 = Color(0xFF10B981)

val BtnOwnLocGrad1 = Color(0xFF0284C7)
val BtnOwnLocGrad2 = Color(0xFF06B6D4)

val BtnSendLocGrad1 = Color(0xFFD97706)
val BtnSendLocGrad2 = Color(0xFFF59E0B)

val BtnMapGrad1 = Color(0xFF7C3AED)
val BtnMapGrad2 = Color(0xFF8B5CF6)

val DeveloperBadgeBg = Color(0xFF1E293B)
val DeveloperBadgeBorder = Color(0xFF00E5FF)
val DeveloperGold = Color(0xFFFFD700)
