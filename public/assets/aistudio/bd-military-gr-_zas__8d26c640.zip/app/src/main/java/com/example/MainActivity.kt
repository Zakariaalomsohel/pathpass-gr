package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.MainCalculatorScreen
import com.example.ui.screens.MilitaryMapViewerScreen
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    CALCULATOR,
    MAP_VIEWER
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    MilitaryAppContent(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun MilitaryAppContent(modifier: Modifier = Modifier) {
    var currentScreen by remember { mutableStateOf(AppScreen.CALCULATOR) }
    var activeLat by remember { mutableDoubleStateOf(24.582254) }
    var activeLon by remember { mutableDoubleStateOf(90.141237) }

    when (currentScreen) {
        AppScreen.CALCULATOR -> {
            MainCalculatorScreen(
                initialLat = activeLat,
                initialLon = activeLon,
                onNavigateToMapViewer = {
                    currentScreen = AppScreen.MAP_VIEWER
                },
                modifier = modifier
            )
        }

        AppScreen.MAP_VIEWER -> {
            MilitaryMapViewerScreen(
                currentLat = activeLat,
                currentLon = activeLon,
                onCoordinateSelected = { lat, lon ->
                    activeLat = lat
                    activeLon = lon
                    currentScreen = AppScreen.CALCULATOR
                },
                onBack = {
                    currentScreen = AppScreen.CALCULATOR
                },
                modifier = modifier
            )
        }
    }
}
