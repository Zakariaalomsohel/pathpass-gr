package com.example

import com.example.calculator.GeodeticCalculator
import com.example.calculator.MilitaryGridCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testUserScreenshotPoint2() {
        // Point 2: lat: 24.582254, lon: 90.141237
        // Screenshot displays:
        // GR: 146184
        // Map Sheet: 78 L/2
        val result = MilitaryGridCalculator.calculate(24.582254, 90.141237)
        assertEquals("146184", result.gr6)
        assertEquals("78 L/2", result.mapSheet50k)
        assertTrue(result.isWithinBangladesh)
    }

    @Test
    fun testPoint1() {
        // Point 1: GR-004089 (78L/3) lat:24.4961502, Long:90.0014501
        val result = MilitaryGridCalculator.calculate(24.4961502, 90.0014501)
        assertEquals("004089", result.gr6)
        assertEquals("78 L/3", result.mapSheet50k)
    }

    @Test
    fun testMapSheetsForPoints() {
        // Point 4: 78 H/14 (lat:24.6374623, lon:89.9737190)
        val p4 = MilitaryGridCalculator.calculate(24.6374623, 89.9737190)
        assertEquals("78 H/14", p4.mapSheet50k)

        // Point 5: 78 L/6 (lat:24.511492, lon:90.3395672)
        val p5 = MilitaryGridCalculator.calculate(24.511492, 90.3395672)
        assertEquals("78 L/6", p5.mapSheet50k)

        // Point 8: 78 H/13 (lat: 24.7963661, lon:89.989117)
        val p8 = MilitaryGridCalculator.calculate(24.7963661, 89.989117)
        assertEquals("78 H/13", p8.mapSheet50k)
    }

    @Test
    fun testGeodeticCalculation() {
        // Dhaka to Bogura
        val dhakaLat = 23.8103
        val dhakaLon = 90.4125
        val boguraLat = 24.8465
        val boguraLon = 89.3777

        val dist = GeodeticCalculator.calculateHaversineDistance(dhakaLat, dhakaLon, boguraLat, boguraLon)
        val bearing = GeodeticCalculator.calculateBearing(dhakaLat, dhakaLon, boguraLat, boguraLon)

        // Distance is ~154.5 km
        assertTrue("Distance should be approx 154-156 km", dist in 150000.0..160000.0)
        // Bearing is roughly 315° (North-West)
        assertTrue("Bearing should be approx 310°-325°", bearing in 310.0..325.0)
    }
}
