package com.example.calculator

import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Result data class for Military Grid Reference (GR) and Topographical Map Sheet calculations.
 */
data class MilitaryGridResult(
    val gr6: String,            // 6-figure Military Grid Reference, e.g. "146184"
    val gr8: String,            // 8-figure Military Grid Reference, e.g. "14581840"
    val gr10: String,           // 10-figure Military Grid Reference, e.g. "1458318404"
    val mapSheet50k: String,    // 1:50,000 Sheet Number, e.g. "78 L/2"
    val degreeSheet250k: String,// 1:250,000 Sheet, e.g. "78 L"
    val primarySheet1M: Int,    // 1:1,000,000 Sheet, e.g. 78
    val degreeLetter: Char,     // e.g. 'L'
    val subSheetNumber: Int,    // e.g. 2
    val eastingMeters: Double,  // Projected BTM Easting (meters)
    val northingMeters: Double, // Projected BTM Northing (meters)
    val wgsLat: Double,
    val wgsLon: Double,
    val gulshanLat: Double,
    val gulshanLon: Double,
    val isWithinBangladesh: Boolean
)

/**
 * Military Grid Calculator for Bangladesh.
 *
 * Implements:
 * 1. Survey of India / Survey of Bangladesh 1:250,000 and 1:50,000 map sheet numbering system.
 * 2. Coordinate Transformation: WGS84 -> Gulshan 303 (Everest 1830 ellipsoid) via Bursa-Wolf 7 parameters.
 * 3. Transverse Mercator (BTM / TM 90 NE, EPSG:3106):
 *    - Central Meridian = 90.0° E
 *    - Latitude of Origin = 0.0° N
 *    - Scale Factor = 0.9996
 *    - False Easting = 500,000.0 m
 *    - False Northing = 0.0 m
 * 4. Military Grid Reference (6-figure GR, 8-figure, 10-figure).
 */
object MilitaryGridCalculator {

    // WGS84 Ellipsoid constants
    private const val A_WGS = 6378137.0
    private const val F_WGS = 1.0 / 298.257223563
    private const val E2_WGS = 2 * F_WGS - F_WGS * F_WGS

    // Everest 1830 Ellipsoid constants (Gulshan 303)
    private const val A_EV = 6377276.345
    private const val B_EV = 6356075.41314024
    private const val E2_EV = (A_EV * A_EV - B_EV * B_EV) / (A_EV * A_EV)
    private const val EP2_EV = (A_EV * A_EV - B_EV * B_EV) / (B_EV * B_EV)

    // Bursa-Wolf 7 parameters (WGS84 -> Gulshan 303)
    // TOWGS84 values for Gulshan 303 are [283.729, 735.942, 261.143, 0, 0, 0, 0]
    // Forward from WGS84 to Gulshan requires negative translations:
    private const val DX = -283.729
    private const val DY = -735.942
    private const val DZ = -261.143

    // Projection constants for Bangladesh Transverse Mercator (EPSG:3106)
    private const val LON_0_DEG = 90.0
    private const val K0 = 0.9996
    private const val FALSE_EASTING = 500000.0
    private const val FALSE_NORTHING = 0.0

    /**
     * Converts WGS84 Latitude and Longitude to Military Grid Reference and Map Sheet.
     */
    fun calculate(lat: Double, lon: Double): MilitaryGridResult {
        // 1. Check if within Bangladesh broad bounding box
        val isWithinBD = lat in 20.5..26.8 && lon in 88.0..92.8

        // 2. Map Sheet Number calculation (Survey of Bangladesh / SOI standard)
        val (primary1M, letter, subNum) = calculateMapSheet(lat, lon)
        val sheet50k = String.format(Locale.US, "%d %c/%d", primary1M, letter, subNum)
        val sheet250k = String.format(Locale.US, "%d %c", primary1M, letter)

        // 3. WGS84 to Gulshan 303 Datum Transformation
        val (gulshanLat, gulshanLon) = transformWgs84ToGulshan(lat, lon)

        // 4. Project onto Transverse Mercator (BTM)
        val (easting, northing) = projectTransverseMercator(gulshanLat, gulshanLon)

        // 5. Calculate Military Grid Reference (GR)
        // 100km block modulo
        val eMod100k = (easting % 100000.0 + 100000.0) % 100000.0
        val nMod100k = (northing % 100000.0 + 100000.0) % 100000.0

        // 6-figure GR: 100m resolution (3 digits Easting, 3 digits Northing)
        val e6 = Math.round(eMod100k / 100.0).toInt().coerceIn(0, 999)
        val n6 = Math.round(nMod100k / 100.0).toInt().coerceIn(0, 999)
        val gr6 = String.format(Locale.US, "%03d%03d", e6, n6)

        // 8-figure GR: 10m resolution (4 digits Easting, 4 digits Northing)
        val e8 = Math.round(eMod100k / 10.0).toInt().coerceIn(0, 9999)
        val n8 = Math.round(nMod100k / 10.0).toInt().coerceIn(0, 9999)
        val gr8 = String.format(Locale.US, "%04d%04d", e8, n8)

        // 10-figure GR: 1m resolution (5 digits Easting, 5 digits Northing)
        val e10 = Math.round(eMod100k).toInt().coerceIn(0, 99999)
        val n10 = Math.round(nMod100k).toInt().coerceIn(0, 99999)
        val gr10 = String.format(Locale.US, "%05d%05d", e10, n10)

        return MilitaryGridResult(
            gr6 = gr6,
            gr8 = gr8,
            gr10 = gr10,
            mapSheet50k = sheet50k,
            degreeSheet250k = sheet250k,
            primarySheet1M = primary1M,
            degreeLetter = letter,
            subSheetNumber = subNum,
            eastingMeters = easting,
            northingMeters = northing,
            wgsLat = lat,
            wgsLon = lon,
            gulshanLat = gulshanLat,
            gulshanLon = gulshanLon,
            isWithinBangladesh = isWithinBD
        )
    }

    /**
     * Calculates the Survey of Bangladesh / India Topographical Map Sheet number:
     * - Primary 1:1,000,000 sheet (4° x 4°)
     * - Degree 1:250,000 sheet letter ('A' to 'P', column-first, North to South)
     * - Sub-sheet 1:50,000 number (1 to 16, 15' x 15', column-first, North to South)
     */
    fun calculateMapSheet(lat: Double, lon: Double): Triple<Int, Char, Int> {
        // Determine 1:1,000,000 primary sheet number
        // In the SOI indexing scheme:
        // Lat 24°-28°, Lon 88°-92° -> 78
        // Lat 20°-24°, Lon 88°-92° -> 79
        // Lat 24°-28°, Lon 92°-96° -> 83
        // Lat 20°-24°, Lon 92°-96° -> 84
        // Lat 24°-28°, Lon 84°-88° -> 72
        // Lat 20°-24°, Lon 84°-88° -> 73
        val primarySheet = when {
            lat >= 24.0 && lon < 88.0 -> 72
            lat < 24.0 && lon < 88.0 -> 73
            lat >= 24.0 && lon < 92.0 -> 78
            lat < 24.0 && lon < 92.0 -> 79
            lat >= 24.0 -> 83
            else -> 84
        }

        // Relative coordinate within the 4° x 4° block
        val latBase = if (lat >= 24.0) 24.0 else 20.0
        val lonBase = when {
            lon < 88.0 -> 84.0
            lon < 92.0 -> 88.0
            else -> 92.0
        }

        val dLat = (lat - latBase).coerceIn(0.0, 3.9999999)
        val dLon = (lon - lonBase).coerceIn(0.0, 3.9999999)

        // 1:250,000 Degree Sheet Letter (A to P)
        // 4 columns (West to East: 0, 1, 2, 3)
        // 4 rows (North to South: 0 = 3°-4°, 1 = 2°-3°, 2 = 1°-2°, 3 = 0°-1°)
        val col = dLon.toInt().coerceIn(0, 3)
        val row = (3 - dLat.toInt()).coerceIn(0, 3)
        val letterIdx = col * 4 + row
        val letter = ('A'.code + letterIdx).toChar()

        // 1:50,000 Sub-sheet Number (1 to 16)
        // Within the 1° x 1° block, divided into 15' x 15' (0.25° x 0.25°) squares
        val minLat = (dLat - dLat.toInt()) * 60.0
        val minLon = (dLon - dLon.toInt()) * 60.0

        val subCol = (minLon / 15.0).toInt().coerceIn(0, 3)
        val subRow = (3 - (minLat / 15.0).toInt()).coerceIn(0, 3)
        val subNumber = subCol * 4 + subRow + 1

        return Triple(primarySheet, letter, subNumber)
    }

    /**
     * Transforms coordinates from WGS84 datum to Gulshan 303 (Everest 1830) datum.
     */
    private fun transformWgs84ToGulshan(lat: Double, lon: Double): Pair<Double, Double> {
        val phi = Math.toRadians(lat)
        val lam = Math.toRadians(lon)

        // 1. Geodetic to Cartesian on WGS84
        val sinPhi = sin(phi)
        val cosPhi = cos(phi)
        val sinLam = sin(lam)
        val cosLam = cos(lam)

        val nWgs = A_WGS / sqrt(1.0 - E2_WGS * sinPhi * sinPhi)
        val x = nWgs * cosPhi * cosLam
        val y = nWgs * cosPhi * sinLam
        val z = nWgs * (1.0 - E2_WGS) * sinPhi

        // 2. Helmert Translation to Gulshan 303
        val xG = x + DX
        val yG = y + DY
        val zG = z + DZ

        // 3. Cartesian to Geodetic on Everest 1830 (Bowring's method)
        val p = sqrt(xG * xG + yG * yG)
        val theta = atan2(zG * A_EV, p * B_EV)
        val sinTheta = sin(theta)
        val cosTheta = cos(theta)

        val phiG = atan2(
            zG + EP2_EV * B_EV * sinTheta * sinTheta * sinTheta,
            p - E2_EV * A_EV * cosTheta * cosTheta * cosTheta
        )
        val lamG = atan2(yG, xG)

        return Pair(Math.toDegrees(phiG), Math.toDegrees(lamG))
    }

    /**
     * Transverse Mercator Projection (BTM / EPSG:3106) on Everest 1830 Ellipsoid.
     */
    private fun projectTransverseMercator(latDeg: Double, lonDeg: Double): Pair<Double, Double> {
        val phi = Math.toRadians(latDeg)
        val lam = Math.toRadians(lonDeg)
        val lam0 = Math.toRadians(LON_0_DEG)

        val sinPhi = sin(phi)
        val cosPhi = cos(phi)
        val tanPhi = tan(phi)

        val n = A_EV / sqrt(1.0 - E2_EV * sinPhi * sinPhi)
        val t = tanPhi * tanPhi
        val c = EP2_EV * cosPhi * cosPhi
        val a = cosPhi * (lam - lam0)

        // Meridian distance along central meridian
        val m = A_EV * (
            (1.0 - E2_EV / 4.0 - 3.0 * E2_EV * E2_EV / 64.0 - 5.0 * E2_EV * E2_EV * E2_EV / 256.0) * phi
                - (3.0 * E2_EV / 8.0 + 3.0 * E2_EV * E2_EV / 32.0 + 45.0 * E2_EV * E2_EV * E2_EV / 1024.0) * sin(2.0 * phi)
                + (15.0 * E2_EV * E2_EV / 256.0 + 45.0 * E2_EV * E2_EV * E2_EV / 1024.0) * sin(4.0 * phi)
                - (35.0 * E2_EV * E2_EV * E2_EV / 3072.0) * sin(6.0 * phi)
            )

        val a2 = a * a
        val a3 = a2 * a
        val a4 = a2 * a2
        val a5 = a4 * a
        val a6 = a3 * a3

        val easting = K0 * n * (
            a + (1.0 - t + c) * a3 / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * EP2_EV) * a5 / 120.0
            ) + FALSE_EASTING

        val northing = K0 * (
            m + n * tanPhi * (
                a2 / 2.0
                    + (5.0 - t + 9.0 * c + 4.0 * c * c) * a4 / 24.0
                    + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * EP2_EV) * a6 / 720.0
                )
            ) + FALSE_NORTHING

        return Pair(easting, northing)
    }

    /**
     * Bounding box (in degrees lat/lon) for a given 1:50,000 map sheet.
     */
    fun getSheetBounds(primary: Int, letter: Char, subNum: Int): MapSheetBounds {
        val latBase = if (primary in listOf(78, 83, 72)) 24.0 else 20.0
        val lonBase = when (primary) {
            72, 73 -> 84.0
            78, 79 -> 88.0
            else -> 92.0
        }

        val letterIdx = letter.uppercaseChar() - 'A'
        val col = letterIdx / 4
        val row = letterIdx % 4
        val degLatBase = latBase + (3 - row)
        val degLonBase = lonBase + col

        val subIdx = subNum - 1
        val subCol = subIdx / 4
        val subRow = subIdx % 4

        val minLat = degLatBase + (3 - subRow) * 0.25
        val maxLat = minLat + 0.25
        val minLon = degLonBase + subCol * 0.25
        val maxLon = minLon + 0.25

        return MapSheetBounds(
            sheetName = String.format(Locale.US, "%d %c/%d", primary, letter, subNum),
            minLat = minLat,
            maxLat = maxLat,
            minLon = minLon,
            maxLon = maxLon,
            centerLat = (minLat + maxLat) / 2.0,
            centerLon = (minLon + maxLon) / 2.0
        )
    }
}

data class MapSheetBounds(
    val sheetName: String,
    val minLat: Double,
    val maxLat: Double,
    val minLon: Double,
    val maxLon: Double,
    val centerLat: Double,
    val centerLon: Double
)
