package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.calculator.MilitaryGridCalculator
import com.example.calculator.MilitaryGridResult
import com.example.calculator.RealtimeLocationManager
import com.example.ui.components.ColorfulCoordinateField
import com.example.ui.components.ColorfulResultDisplay
import com.example.ui.components.ColorfulTacticalButton
import com.example.ui.components.ParchmentMapBackground
import com.example.ui.components.RealtimeTelemetryHud
import com.example.ui.components.TopDeveloperHeader
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun MainCalculatorScreen(
    initialLat: Double = 24.582254,
    initialLon: Double = 90.141237,
    onNavigateToMapViewer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Real-time Location Manager Service instance
    val locationManager = remember { RealtimeLocationManager.getInstance(context) }
    val trackingState by locationManager.trackingState.collectAsState()

    // Coordinates input state
    var latitudeText by remember { mutableStateOf(String.format(Locale.US, "%.6f", initialLat)) }
    var longitudeText by remember { mutableStateOf(String.format(Locale.US, "%.6f", initialLon)) }

    // Calculation Result State
    var calculationResult by remember {
        mutableStateOf<MilitaryGridResult?>(
            MilitaryGridCalculator.calculate(initialLat, initialLon)
        )
    }

    var locationStatusMessage by remember { mutableStateOf<String?>(null) }
    var showTelemetryHud by remember { mutableStateOf(true) }

    // Sync when initialLat/Lon changes externally (e.g., from Map Viewer selection)
    LaunchedEffect(initialLat, initialLon) {
        latitudeText = String.format(Locale.US, "%.6f", initialLat)
        longitudeText = String.format(Locale.US, "%.6f", initialLon)
        calculationResult = MilitaryGridCalculator.calculate(initialLat, initialLon)
    }

    // When real-time tracking is active, auto-update the inputs and result
    LaunchedEffect(trackingState.latitude, trackingState.longitude, trackingState.isTracking) {
        if (trackingState.isTracking) {
            latitudeText = String.format(Locale.US, "%.6f", trackingState.latitude)
            longitudeText = String.format(Locale.US, "%.6f", trackingState.longitude)
            calculationResult = trackingState.liveResult
        }
    }

    // Function to calculate GR and Map Sheet
    fun performCalculation() {
        val lat = latitudeText.toDoubleOrNull()
        val lon = longitudeText.toDoubleOrNull()
        if (lat == null || lon == null) {
            Toast.makeText(context, "Please enter valid Latitude & Longitude", Toast.LENGTH_SHORT).show()
            return
        }
        val result = MilitaryGridCalculator.calculate(lat, lon)
        calculationResult = result
        if (!result.isWithinBangladesh) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Note: Coordinates are outside Bangladesh border.")
            }
        }
    }

    // Runtime Permission Launcher for Location
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            locationManager.startRealtimeTracking()
            Toast.makeText(context, "Real-time GPS Tracking Started", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Location permission required for GPS tracking", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleRealtimeTracking(enable: Boolean) {
        if (enable) {
            val fineCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            val coarseCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (fineCheck == PackageManager.PERMISSION_GRANTED || coarseCheck == PackageManager.PERMISSION_GRANTED) {
                locationManager.startRealtimeTracking()
            } else {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        } else {
            locationManager.stopRealtimeTracking()
        }
    }

    fun fetchSingleOwnLocation() {
        val fineCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarseCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fineCheck == PackageManager.PERMISSION_GRANTED || coarseCheck == PackageManager.PERMISSION_GRANTED) {
            locationStatusMessage = "Acquiring high-accuracy GPS fix..."
            locationManager.requestSingleUpdate { success ->
                if (success) {
                    val lat = locationManager.trackingState.value.latitude
                    val lon = locationManager.trackingState.value.longitude
                    latitudeText = String.format(Locale.US, "%.6f", lat)
                    longitudeText = String.format(Locale.US, "%.6f", lon)
                    performCalculation()
                    locationStatusMessage = "Location updated (±${String.format(Locale.US, "%.1f", locationManager.trackingState.value.accuracyMeters)}m)"
                    Toast.makeText(context, "Own GPS Location Acquired", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Unable to get GPS fix. Ensure GPS is on.", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // Function to Send / Share Location
    fun onSendLocationClicked() {
        val result = calculationResult ?: MilitaryGridCalculator.calculate(
            latitudeText.toDoubleOrNull() ?: 24.582254,
            longitudeText.toDoubleOrNull() ?: 90.141237
        )
        val lat = latitudeText
        val lon = longitudeText
        val gr = result.gr6
        val sheet = result.mapSheet50k

        val shareText = """
            [MILITARY SITREP - COORDINATE REPORT]
            Latitude: $lat
            Longitude: $lon
            Grid Reference (GR): $gr (6-Figure)
            Map Sheet: $sheet (1:50,000 Topo)
            BTM Coordinates: E: ${String.format(Locale.US, "%.1f", result.eastingMeters)}m, N: ${String.format(Locale.US, "%.1f", result.northingMeters)}m
            Google Map: https://maps.google.com/?q=$lat,$lon
            
            Developed & Reported by:
            1618101 Cpl (Tech) Md. Zakaria Alom
            3 Signal Battalion • Bangladesh Army
        """.trimIndent()

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Military Location: GR $gr ($sheet)")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        context.startActivity(Intent.createChooser(sendIntent, "Send Military Location via"))
    }

    // Function to View in Google Map
    fun onViewInGoogleMapClicked() {
        val lat = latitudeText.toDoubleOrNull() ?: 24.582254
        val lon = longitudeText.toDoubleOrNull() ?: 90.141237
        val gr = calculationResult?.gr6 ?: ""
        val sheet = calculationResult?.mapSheet50k ?: ""
        val label = Uri.encode("GR: $gr ($sheet)")

        val geoUri = Uri.parse("geo:$lat,$lon?q=$lat,$lon($label)")
        val mapIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            setPackage("com.google.android.apps.maps")
        }
        try {
            context.startActivity(mapIntent)
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$lat,$lon"))
            context.startActivity(webIntent)
        }
    }

    // Copy helper
    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Military Coordinate", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$text copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    // Paste helper
    fun pasteCoordinate(isLat: Boolean) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).text.toString().trim()
            if (isLat) latitudeText = text else longitudeText = text
            performCalculation()
        }
    }

    ParchmentMapBackground {
        Box(modifier = modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. DEVELOPER IDENTITY AT TOP IN ENGLISH (Per User Request)
                TopDeveloperHeader(modifier = Modifier.padding(bottom = 12.dp))

                // Title & Map Button Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LATITUDE & LONGITUDE TO GR",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 19.sp,
                            letterSpacing = 1.1.sp,
                            color = Color(0xFFF8FAFC)
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    // Button to open Military Map Sheet Viewer
                    Surface(
                        color = Color(0xFF7C3AED),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clickable { onNavigateToMapViewer() }
                            .testTag("map_viewer_nav_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Map,
                                contentDescription = "Military Map",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "MAP VIEWER",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Real-time Location Tracking Telemetry HUD
                if (showTelemetryHud) {
                    RealtimeTelemetryHud(
                        trackingState = trackingState,
                        onToggleTracking = { toggleRealtimeTracking(it) },
                        onCenterOnUser = {
                            latitudeText = String.format(Locale.US, "%.6f", trackingState.latitude)
                            longitudeText = String.format(Locale.US, "%.6f", trackingState.longitude)
                            performCalculation()
                        },
                        onClearTrail = { locationManager.clearTrail() },
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                // Coordinate Input Section
                ColorfulCoordinateField(
                    label = "Latitude:",
                    value = latitudeText,
                    onValueChange = {
                        latitudeText = it
                        performCalculation()
                    },
                    placeholder = "24.582254",
                    onClear = { latitudeText = "" },
                    onPaste = { pasteCoordinate(isLat = true) },
                    testTag = "latitude_input"
                )

                ColorfulCoordinateField(
                    label = "Longitude:",
                    value = longitudeText,
                    onValueChange = {
                        longitudeText = it
                        performCalculation()
                    },
                    placeholder = "90.141237",
                    labelColor = CyberGold,
                    onClear = { longitudeText = "" },
                    onPaste = { pasteCoordinate(isLat = false) },
                    onDone = { performCalculation() },
                    testTag = "longitude_input"
                )

                // GPS Status message if active
                if (locationStatusMessage != null) {
                    Text(
                        text = locationStatusMessage!!,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonGreen,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                // Primary Output Display: GR and Map Sheet
                ColorfulResultDisplay(
                    result = calculationResult,
                    onCopy = { copyToClipboard(it) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Primary Action Button 1: SHOW GR & MAP SHEET (Emerald Gradient)
                ColorfulTacticalButton(
                    text = "SHOW GR & MAP SHEET",
                    onClick = { performCalculation() },
                    gradient = Brush.horizontalGradient(
                        listOf(Color(0xFF059669), Color(0xFF10B981))
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    testTag = "show_gr_button"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons Row: OWN LOCATION (Cyan) & SEND LOCATION (Amber/Orange)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ColorfulTacticalButton(
                        text = if (trackingState.isTracking) "TRACKING ACTIVE" else "OWN LOCATION",
                        onClick = {
                            if (!trackingState.isTracking) {
                                fetchSingleOwnLocation()
                            } else {
                                latitudeText = String.format(Locale.US, "%.6f", trackingState.latitude)
                                longitudeText = String.format(Locale.US, "%.6f", trackingState.longitude)
                                performCalculation()
                            }
                        },
                        icon = Icons.Default.GpsFixed,
                        gradient = Brush.horizontalGradient(
                            listOf(Color(0xFF0284C7), Color(0xFF06B6D4))
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        testTag = "own_location_button"
                    )

                    ColorfulTacticalButton(
                        text = "SEND LOCATION",
                        onClick = { onSendLocationClicked() },
                        icon = Icons.Default.Send,
                        gradient = Brush.horizontalGradient(
                            listOf(Color(0xFFD97706), Color(0xFFF59E0B))
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        testTag = "send_location_button"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // VIEW IN GOOGLE MAP Button (Purple / Violet Gradient)
                ColorfulTacticalButton(
                    text = "VIEW IN GOOGLE MAP",
                    onClick = { onViewInGoogleMapClicked() },
                    icon = Icons.Default.Place,
                    gradient = Brush.horizontalGradient(
                        listOf(Color(0xFF7C3AED), Color(0xFF8B5CF6))
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    testTag = "view_google_map_button"
                )

                // (Note: The test reference points chips have been removed as explicitly requested)

                Spacer(modifier = Modifier.height(24.dp))
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
