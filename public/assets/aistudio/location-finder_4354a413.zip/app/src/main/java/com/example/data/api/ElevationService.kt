package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ElevationService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    // In-memory cache for fast repeated queries
    private val cache = mutableMapOf<String, Double>()

    suspend fun getElevation(lat: Double, lon: Double, context: android.content.Context? = null): Result<Double> = withContext(Dispatchers.IO) {
        val cacheKey = "${"%.4f".format(lat)},${"%.4f".format(lon)}"
        cache[cacheKey]?.let { return@withContext Result.success(it) }

        try {
            val url = "https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (body != null) {
                        val json = JSONObject(body)
                        val elevArray = json.optJSONArray("elevation")
                        if (elevArray != null && elevArray.length() > 0) {
                            val elev = elevArray.getDouble(0)
                            cache[cacheKey] = elev
                            return@withContext Result.success(elev)
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Network failed or offline - proceed to offline cache lookup
        }

        // Offline Fallback: Check local Room cached elevation database
        if (context != null) {
            try {
                val offlineElev = com.example.data.model.OfflineMapManager.getOfflineElevation(context, lat, lon)
                if (offlineElev != null) {
                    cache[cacheKey] = offlineElev
                    return@withContext Result.success(offlineElev)
                }
            } catch (_: Exception) {
                // Ignore DB error
            }
        }

        Result.failure(Exception("ইন্টারনেট সংযোগ নেই বা এলিভেশন পাওয়া যায়নি"))
    }

    suspend fun getElevationBatch(points: List<Pair<Double, Double>>): Map<Int, Double> = withContext(Dispatchers.IO) {
        if (points.isEmpty()) return@withContext emptyMap()
        try {
            val lats = points.joinToString(",") { it.first.toString() }
            val lons = points.joinToString(",") { it.second.toString() }
            val url = "https://api.open-meteo.com/v1/elevation?latitude=$lats&longitude=$lons"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext emptyMap()
                    val json = JSONObject(body)
                    val elevArray = json.optJSONArray("elevation")
                    val result = mutableMapOf<Int, Double>()
                    if (elevArray != null) {
                        for (i in 0 until elevArray.length()) {
                            val elev = elevArray.getDouble(i)
                            result[i] = elev
                            val cacheKey = "${"%.4f".format(points[i].first)},${"%.4f".format(points[i].second)}"
                            cache[cacheKey] = elev
                        }
                    }
                    result
                } else {
                    emptyMap()
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
