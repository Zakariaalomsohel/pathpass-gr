package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = TacticalEmerald,
    onPrimary = Color.Black,
    primaryContainer = TacticalEmeraldDark,
    onPrimaryContainer = TacticalEmeraldLight,
    secondary = TacticalCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF0E7490),
    onSecondaryContainer = Color(0xFFA5F3FC),
    tertiary = TacticalAmber,
    onTertiary = Color.Black,
    background = TacticalDarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = TacticalDarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = TacticalDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = TacticalCardBorder,
    error = TacticalRed
)

private val LightColorScheme = lightColorScheme(
    primary = TacticalLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF065F46),
    secondary = TacticalLightSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = TacticalLightTertiary,
    onTertiary = Color.White,
    background = TacticalLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = TacticalLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = TacticalLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFDC2626)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep tactical theme consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
