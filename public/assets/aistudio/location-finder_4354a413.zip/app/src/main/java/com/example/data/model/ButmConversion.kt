package com.example.data.model

import java.text.DecimalFormat
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Bangladesh UTM (BUTM) Grid ↔ Lat/Long Converter
 * Based on Everest 1830 Datum
 * Original logic from GR Converter by Capt Tahsin Abdullah
 * Developed By : 1618101 Cpl (Tech) Md Zakaria Alom, 3 Sigbn
 */
object ButmConversion {

    // ---- Constants (Everest 1830 + BUTM parameters) ----
    private const val FE_U = 500000.0 // False Easting (meters)
    private const val FN_U = 0.0      // False Northing (meters)

    private const val ae = 6377276.345          // Semi-major axis (meters) - Everest 1830
    private const val fe = 0.003324449296662885 // Flattening (1 / 300.8017)
    private const val be = ae * (1.0 - fe)
    private const val pi = 3.1415926535898
    private const val cdr = pi / 180.0
    private const val crd = 180.0 / pi
    private const val e2e = fe * (2.0 - fe)
    private const val ko_U = 0.9996             // Scale factor
    private const val lnod_U = 90               // Central Meridian: 90° E
    private const val lnor_U = lnod_U * cdr
    private const val ltod_U = 0                // Latitude of Origin: 0° (Equator)
    private const val ltor_U = ltod_U * cdr
    private const val ne = fe / (2.0 - fe)
    private val re = (ae * ((ne.pow(2.0) / 4.0) + 1.0)) / (ne + 1.0)
    private val se2e = e2e / (1.0 - fe).pow(2.0)

    // Data structures for results
    data class ButmResult(
        val easting: Double,
        val northing: Double,
        val mapSheetNo: String,
        val militaryGr8: String,
        val militaryGr6: String
    ) {
        val eastingFormatted: String get() = "%.2f".format(Locale.US, easting)
        val northingFormatted: String get() = "%.2f".format(Locale.US, northing)
    }

    data class LatLonResult(
        val latitude: Double,
        val longitude: Double,
        val latDms: String,
        val lonDms: String,
        val mapSheetNo: String
    ) {
        val latFormatted: String get() = "%.5f".format(Locale.US, latitude)
        val lonFormatted: String get() = "%.5f".format(Locale.US, longitude)
    }

    data class DmsParts(
        val degrees: Int,
        val minutes: Int,
        val seconds: Double,
        val isNegative: Boolean
    ) {
        fun format(isLatitude: Boolean): String {
            val dir = if (isLatitude) {
                if (isNegative) "S" else "N"
            } else {
                if (isNegative) "W" else "E"
            }
            return "%d° %02d' %05.2f\" %s".format(Locale.US, degrees, minutes, seconds, dir)
        }
    }

    /**
     * Converts Decimal degrees to DMS parts
     */
    fun decimalToDmsParts(decimal: Double): DmsParts {
        val isNeg = decimal < 0
        val absVal = kotlin.math.abs(decimal)
        val deg = absVal.toInt()
        val remainder = (absVal - deg) * 60.0
        val min = remainder.toInt()
        val sec = (remainder - min) * 60.0
        return DmsParts(degrees = deg, minutes = min, seconds = roundTwoDecimals(sec), isNegative = isNeg)
    }

    /**
     * Converts DMS (degree, minute, second) to Decimal degrees
     */
    fun dmsToDecimal(degree: Double, min: Double, sec: Double, isNegative: Boolean = false): Double {
        val dec = degree + (min * 60.0 + sec) / 3600.0
        val res = roundFiveDecimals(dec)
        return if (isNegative) -res else res
    }

    /**
     * Lat/Long (decimal degrees, Everest 1830) → BUTM Grid (Easting, Northing)
     */
    fun latLonToButmGrid(latDeg: Double, lonDeg: Double): ButmResult {
        val lat = latDeg * cdr
        val lon = lonDeg * cdr

        val d1 = lon - lnor_U
        val d2 = sin(lat)
        val d3 = cos(lat)
        val d4 = tan(lat)
        val d5 = se2e * d3 * d3

        val nVal = ae / sqrt(1.0 - e2e * d2 * d2)
        val tVal = d4 * d4
        val cVal = d5
        val aVal = d3 * d1
        val mVal = meridDistForward(lat)

        val easting = ko_U * nVal * (aVal + (aVal.pow(3) / 6.0) * (1.0 - tVal + cVal)
                + (aVal.pow(5) / 120.0) * (5.0 - 18.0 * tVal + tVal * tVal + 72.0 * cVal - 58.0 * se2e)) + FE_U

        val northing = ko_U * (mVal + nVal * d4 * ((aVal * aVal / 2.0) + (aVal.pow(4) / 24.0) * (5.0 - tVal + 9.0 * cVal + 4.0 * cVal * cVal)
                + (aVal.pow(6) / 720.0) * (61.0 - 58.0 * tVal + tVal * tVal + 600.0 * cVal - 330.0 * se2e))) + FN_U

        val roundedEasting = roundTwoDecimals(easting)
        val roundedNorthing = roundTwoDecimals(northing)

        val dmsLat = decimalToDmsParts(latDeg)
        val dmsLon = decimalToDmsParts(lonDeg)
        val sheetNo = calculateMapSheet(dmsLat.degrees, dmsLat.minutes.toDouble(), dmsLon.degrees, dmsLon.minutes.toDouble())

        // Calculate 8-figure and 6-figure military grid reference (GR)
        // Extract 100km, 10km, 1km, 100m, 10m digits
        val eInt = (roundedEasting % 100000).toInt()
        val nInt = (roundedNorthing % 100000).toInt()
        val e4 = "%04d".format(Locale.US, eInt / 10)
        val n4 = "%04d".format(Locale.US, nInt / 10)
        val gr8 = "$e4 $n4"
        val gr6 = "${e4.substring(0, 3)} ${n4.substring(0, 3)}"

        return ButmResult(
            easting = roundedEasting,
            northing = roundedNorthing,
            mapSheetNo = sheetNo,
            militaryGr8 = gr8,
            militaryGr6 = gr6
        )
    }

    /**
     * BUTM Grid (Easting, Northing) → Lat/Long (Everest 1830)
     */
    fun butmGridToLatLon(easting: Double, northing: Double): LatLonResult {
        val d1 = easting - FE_U
        val d2 = northing - FN_U

        val sMd = meridDistForward(ltor_U)
        val ltFp = meridDistInverse((sMd + d2) / ((ko_U * re) * crd))

        val d3 = ltFp
        val d4 = (ko_U * ae) / sqrt(1.0 - (e2e * sin(d3).pow(2)))
        val d5 = d1 / d4

        val d6 = tan(d3).pow(2)
        val d7 = se2e * cos(d3).pow(2)
        val d8 = sqrt(d6) * (1.0 + d7)

        val lat = d3 - ((d5 * d5) / 2.0) * d8 * (1.0 - (d5 * d5 / 24.0) * (5.0 + 3.0 * d6 + d7 * (1.0 - 9.0 * d6) - 4.0 * d7)
                + (d5.pow(4) / 720.0) * (61.0 + 90.0 * d6 + 45.0 * d6 * d6))

        val lon = lnor_U + (d5 / cos(d3)) * (1.0 - (d5 * d5 / 6.0) * (1.0 + 2.0 * d6 + d7)
                + (d5.pow(4) / 120.0) * (5.0 + 28.0 * d6 + 24.0 * d6 * d6))

        val latDeg = roundFiveDecimals(lat * crd)
        val lonDeg = roundFiveDecimals(lon * crd)

        val dmsLat = decimalToDmsParts(latDeg)
        val dmsLon = decimalToDmsParts(lonDeg)
        val sheetNo = calculateMapSheet(dmsLat.degrees, dmsLat.minutes.toDouble(), dmsLon.degrees, dmsLon.minutes.toDouble())

        return LatLonResult(
            latitude = latDeg,
            longitude = lonDeg,
            latDms = dmsLat.format(isLatitude = true),
            lonDms = dmsLon.format(isLatitude = false),
            mapSheetNo = sheetNo
        )
    }

    /**
     * Bangladesh Survey Map Sheet Number calculation (1:50,000 sheet)
     */
    fun calculateMapSheet(latDeg: Int, latMin: Double, lonDeg: Int, lonMin: Double): String {
        val key = "$lonDeg-$latDeg"
        val sheetMap = mapOf(
            "88-25" to "78 C",
            "88-26" to "78 B",
            "88-24" to "78 D",
            "89-25" to "78 G",
            "89-26" to "78 F",
            "89-24" to "78 H",
            "89-23" to "78 L",
            "89-22" to "78 P",
            "89-21" to "79 E",
            "90-25" to "78 K",
            "90-26" to "78 J",
            "90-24" to "78 I",
            "90-23" to "79 J",
            "90-22" to "79 F",
            "90-21" to "79 G",
            "91-25" to "78 O",
            "91-24" to "78 N",
            "91-23" to "79 M",
            "91-22" to "79 N",
            "91-21" to "79 O",
            "92-24" to "83 D",
            "92-23" to "84 A",
            "92-22" to "84 B",
            "92-21" to "84 C"
        )

        val baseSheet = sheetMap[key] ?: if (lonDeg in 88..92 && latDeg in 20..26) "79 J" else "Unknown"
        val row = (latMin / 15.0).toInt().coerceIn(0, 3)
        val col = (lonMin / 15.0).toInt().coerceIn(0, 3)
        val ival = (3 - row) * 4 + (col + 1) // 1 to 16
        return "$baseSheet/$ival"
    }

    // ====================== HELPER METHODS ======================

    private fun meridDistForward(lat: Double): Double {
        val e2 = e2e
        val e4 = e2 * e2
        val e6 = e4 * e2
        val a0 = 1.0 - e2 / 4.0 - 3.0 * e4 / 64.0 - 5.0 * e6 / 256.0
        val a2 = 3.0 / 8.0 * (e2 + e4 / 4.0 + 15.0 * e6 / 128.0)
        val a4 = 15.0 / 256.0 * (e4 + 3.0 * e6 / 4.0)
        val a6 = 35.0 * e6 / 3072.0
        return ae * (a0 * lat - a2 * sin(2 * lat) + a4 * sin(4 * lat) - a6 * sin(6 * lat))
    }

    private fun meridDistInverse(m: Double): Double {
        val mu = m / (ae * (1.0 - e2e / 4.0 - 3.0 * e2e * e2e / 64.0))
        val e1 = (1.0 - sqrt(1.0 - e2e)) / (1.0 + sqrt(1.0 - e2e))
        return mu + (3.0 * e1 / 2.0 - 27.0 * e1.pow(3) / 32.0) * sin(2 * mu) +
                (21.0 * e1 * e1 / 16.0 - 55.0 * e1.pow(4) / 32.0) * sin(4 * mu) +
                (151.0 * e1.pow(3) / 96.0) * sin(6 * mu)
    }

    private fun roundTwoDecimals(v: Double): Double {
        return try {
            DecimalFormat("#.##").format(v).toDouble()
        } catch (_: Exception) {
            (v * 100.0).roundToLong() / 100.0
        }
    }

    private fun roundFiveDecimals(v: Double): Double {
        return try {
            DecimalFormat("#.#####").format(v).toDouble()
        } catch (_: Exception) {
            (v * 100000.0).roundToLong() / 100000.0
        }
    }

    private fun Double.roundToLong(): Long = kotlin.math.round(this).toLong()
}
