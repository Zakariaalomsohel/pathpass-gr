package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Grid4x4
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ButmConversion
import com.example.ui.MainViewModel

@Composable
fun ButmConverterScreen(
    viewModel: MainViewModel,
    onNavigateBackToCalc: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Lat/Lon -> BUTM, 1: BUTM -> Lat/Lon

    // Inputs for Forward (Lat/Lon -> BUTM)
    var inputLat by remember { mutableStateOf("23.8103") }
    var inputLon by remember { mutableStateOf("90.4125") }
    var forwardResult by remember { mutableStateOf<ButmConversion.ButmResult?>(null) }

    // Inputs for Reverse (BUTM -> Lat/Lon)
    var inputEasting by remember { mutableStateOf("542018.42") }
    var inputNorthing by remember { mutableStateOf("2633814.15") }
    var reverseResult by remember { mutableStateOf<ButmConversion.LatLonResult?>(null) }

    val currentGps by viewModel.currentGps.collectAsState()
    val p1Lat by viewModel.p1Lat.collectAsState()
    val p1Lon by viewModel.p1Lon.collectAsState()
    val p2Lat by viewModel.p2Lat.collectAsState()
    val p2Lon by viewModel.p2Lon.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Screen Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Grid4x4,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "BANGLADESH UTM (BUTM) GRID",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Everest 1830 Datum ↔ Geographic Lat/Long",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Original logic from GR Converter by Capt Tahsin Abdullah | Central Meridian 90°E",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Conversion Mode Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Lat/Lon → BUTM Grid", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("BUTM Grid → Lat/Lon", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            // ================= FORWARD CONVERSION: LAT/LON -> BUTM =================
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ইনপুট: ভৌগোলিক স্থানাঙ্ক (Geographic Coordinates)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = inputLat,
                            onValueChange = { inputLat = it },
                            label = { Text("অক্ষাংশ (Latitude °N)", fontSize = 11.sp) },
                            placeholder = { Text("23.8103") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("butm_input_lat"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = inputLon,
                            onValueChange = { inputLon = it },
                            label = { Text("দ্রাঘিমাংশ (Longitude °E)", fontSize = 11.sp) },
                            placeholder = { Text("90.4125") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("butm_input_lon"),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Load Action Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                currentGps?.let {
                                    inputLat = it.latitude.toString()
                                    inputLon = it.longitude.toString()
                                } ?: Toast.makeText(context, "GPS লোকেশন পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("My GPS", fontSize = 11.sp)
                        }

                        if (p1Lat.isNotBlank() && p1Lon.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    inputLat = p1Lat
                                    inputLon = p1Lon
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Load Point 1", fontSize = 11.sp)
                            }
                        }

                        if (p2Lat.isNotBlank() && p2Lon.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    inputLat = p2Lat
                                    inputLon = p2Lon
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Load Point 2", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Convert Button
                    Button(
                        onClick = {
                            val lat = inputLat.trim().toDoubleOrNull()
                            val lon = inputLon.trim().toDoubleOrNull()
                            if (lat != null && lon != null) {
                                forwardResult = ButmConversion.latLonToButmGrid(lat, lon)
                            } else {
                                Toast.makeText(context, "সঠিক Lat ও Lon লিখুন", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("convert_to_butm_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.SyncAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("BUTM গ্রিডে রূপান্তর করুন (Convert to BUTM)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            // Results of Forward Conversion
            AnimatedVisibility(visible = forwardResult != null) {
                forwardResult?.let { res ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Spacer(modifier = Modifier.height(14.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "BUTM গ্রিড ফলাফল (EVEREST 1830 DATUM)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Easting & Northing display
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ResultMetricBox(
                                        title = "ইস্টিং (Easting)",
                                        value = "${res.eastingFormatted} m",
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.eastingFormatted, "Easting") }
                                    )

                                    ResultMetricBox(
                                        title = "নর্দিং (Northing)",
                                        value = "${res.northingFormatted} m",
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.northingFormatted, "Northing") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Military GR and Map Sheet
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ResultMetricBox(
                                        title = "৮-ডিজিট GR (8-Fig GR)",
                                        value = res.militaryGr8,
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.militaryGr8, "8-Fig GR") }
                                    )

                                    ResultMetricBox(
                                        title = "ম্যাপ শীট (Map Sheet No)",
                                        value = res.mapSheetNo,
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.mapSheetNo, "Map Sheet No") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // 6-Figure GR
                                ResultMetricBox(
                                    title = "৬-ডিজিট মিলিটারি GR (6-Figure Tactical GR)",
                                    value = res.militaryGr6,
                                    modifier = Modifier.fillMaxWidth(),
                                    onCopy = { copyToClipboard(context, res.militaryGr6, "6-Fig GR") }
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Direct Actions: Send to Point 1 or Point 2 in Calculator
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val lat = inputLat.toDoubleOrNull() ?: 0.0
                                            val lon = inputLon.toDoubleOrNull() ?: 0.0
                                            viewModel.setCoordinatesAsPoint1(lat, lon)
                                            onNavigateBackToCalc()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Set Point 1", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val lat = inputLat.toDoubleOrNull() ?: 0.0
                                            val lon = inputLon.toDoubleOrNull() ?: 0.0
                                            viewModel.setCoordinatesAsPoint2(lat, lon)
                                            onNavigateBackToCalc()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Set Point 2", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // ================= REVERSE CONVERSION: BUTM -> LAT/LON =================
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ইনপুট: BUTM গ্রিড (Easting & Northing Meters)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = inputEasting,
                            onValueChange = { inputEasting = it },
                            label = { Text("ইস্টিং (Easting m)", fontSize = 11.sp) },
                            placeholder = { Text("542018.42") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("butm_input_easting"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = inputNorthing,
                            onValueChange = { inputNorthing = it },
                            label = { Text("নর্দিং (Northing m)", fontSize = 11.sp) },
                            placeholder = { Text("2633814.15") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("butm_input_northing"),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Convert Button
                    Button(
                        onClick = {
                            val easting = inputEasting.trim().toDoubleOrNull()
                            val northing = inputNorthing.trim().toDoubleOrNull()
                            if (easting != null && northing != null) {
                                reverseResult = ButmConversion.butmGridToLatLon(easting, northing)
                            } else {
                                Toast.makeText(context, "সঠিক Easting ও Northing লিখুন", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("convert_from_butm_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.SyncAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Lat/Lon এ রূপান্তর করুন (Convert to Lat/Lon)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            // Results of Reverse Conversion
            AnimatedVisibility(visible = reverseResult != null) {
                reverseResult?.let { res ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Spacer(modifier = Modifier.height(14.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "ভৌগোলিক স্থানাঙ্ক ফলাফল (GEOGRAPHIC COORDINATES)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Decimal degrees
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ResultMetricBox(
                                        title = "অক্ষাংশ (Decimal Latitude)",
                                        value = "${res.latFormatted}°",
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.latFormatted, "Latitude") }
                                    )

                                    ResultMetricBox(
                                        title = "দ্রাঘিমাংশ (Decimal Longitude)",
                                        value = "${res.lonFormatted}°",
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.lonFormatted, "Longitude") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // DMS values
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ResultMetricBox(
                                        title = "Latitude DMS",
                                        value = res.latDms,
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.latDms, "Lat DMS") }
                                    )

                                    ResultMetricBox(
                                        title = "Longitude DMS",
                                        value = res.lonDms,
                                        modifier = Modifier.weight(1f),
                                        onCopy = { copyToClipboard(context, res.lonDms, "Lon DMS") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                ResultMetricBox(
                                    title = "ম্যাপ শীট (Bangladesh Survey Sheet)",
                                    value = res.mapSheetNo,
                                    modifier = Modifier.fillMaxWidth(),
                                    onCopy = { copyToClipboard(context, res.mapSheetNo, "Map Sheet No") }
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Actions: Send to Calculator or Open in Maps
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.setCoordinatesAsPoint1(res.latitude, res.longitude)
                                            onNavigateBackToCalc()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Set Point 1", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            viewModel.setCoordinatesAsPoint2(res.latitude, res.longitude)
                                            onNavigateBackToCalc()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Set Point 2", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val uri = Uri.parse("geo:${res.latitude},${res.longitude}?q=${res.latitude},${res.longitude}(BUTM)")
                                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Map", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // DEVELOPER ATTRIBUTION (VERBATIM)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Developed By : 1618101 Cpl (Tech) Md Zakaria Alom, 3 Sigbn",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Everest 1830 Datum • Central Meridian 90°E • Scale 0.9996",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
private fun ResultMetricBox(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    onCopy: () -> Unit
) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }

            IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String, label: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$label কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
}
