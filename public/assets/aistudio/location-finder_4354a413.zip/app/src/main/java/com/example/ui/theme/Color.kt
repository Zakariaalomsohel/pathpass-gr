package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Navigation Color Palette
val TacticalDarkBackground = Color(0xFF090D16)
val TacticalDarkSurface = Color(0xFF111827)
val TacticalDarkSurfaceVariant = Color(0xFF1E293B)
val TacticalCardBorder = Color(0xFF334155)

val TacticalEmerald = Color(0xFF10B981)
val TacticalEmeraldLight = Color(0xFF34D399)
val TacticalEmeraldDark = Color(0xFF065F46)

val TacticalCyan = Color(0xFF06B6D4)
val TacticalAmber = Color(0xFFF59E0B)
val TacticalRed = Color(0xFFEF4444)

// Light Theme Palette
val TacticalLightBackground = Color(0xFFF8FAFC)
val TacticalLightSurface = Color(0xFFFFFFFF)
val TacticalLightSurfaceVariant = Color(0xFFF1F5F9)
val TacticalLightPrimary = Color(0xFF059669)
val TacticalLightSecondary = Color(0xFF0284C7)
val TacticalLightTertiary = Color(0xFFD97706)
