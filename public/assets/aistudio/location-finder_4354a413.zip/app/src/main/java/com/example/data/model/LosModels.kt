package com.example.data.model

import kotlin.math.sqrt

data class AntennaConfig(
    val p1HeightMeters: Double = 15.0, // Site A Mast Height
    val p2HeightMeters: Double = 15.0, // Site B Mast Height
    val frequencyMhz: Double = 400.0   // Military Tactical VHF/UHF/Microwave
)

data class TerrainPoint(
    val distanceFraction: Float, // 0.0 (Site A) to 1.0 (Site B)
    val groundElevationMeters: Double,
    val earthBulgeMeters: Double,
    val losBeamHeightMeters: Double,
    val fresnelRadiusMeters: Double
)

data class LosAnalysisResult(
    val isLosClear: Boolean,
    val clearanceMarginMeters: Double,
    val earthCurvatureBulgeMeters: Double,
    val fresnelZoneRadiusMeters: Double,
    val statusText: String,
    val statusColorType: StatusColor,
    val recommendation: String,
    val points: List<TerrainPoint>
) {
    enum class StatusColor {
        CLEAR,
        MARGINAL,
        OBSTRUCTED
    }
}

object LosCalculator {

    // K-factor for standard atmospheric refraction = 4/3
    private const val K_FACTOR = 4.0 / 3.0
    private const val EARTH_RADIUS_KM = 6371.0

    fun calculateLineOfSight(
        distanceKm: Double,
        p1Elevation: Double,
        p1AntennaHeight: Double,
        p2Elevation: Double,
        p2AntennaHeight: Double,
        frequencyMhz: Double = 400.0
    ): LosAnalysisResult {
        if (distanceKm <= 0.0) {
            return LosAnalysisResult(
                isLosClear = true,
                clearanceMarginMeters = p1AntennaHeight,
                earthCurvatureBulgeMeters = 0.0,
                fresnelZoneRadiusMeters = 0.0,
                statusText = "LOS Clear (একই স্থান)",
                statusColorType = LosAnalysisResult.StatusColor.CLEAR,
                recommendation = "উভয় এন্টেনা একই স্থানে অবস্থিত।",
                points = emptyList()
            )
        }

        val totalHeight1 = p1Elevation + p1AntennaHeight
        val totalHeight2 = p2Elevation + p2AntennaHeight

        // Maximum Earth curvature bulge at midpoint: h = d1*d2 / (2 * k * R)
        // With d in km and R = 6371 km, h in meters = (d/2)^2 / (2 * 1.333 * 6371 / 1000)
        // Simplified: h_mid ≈ D_km^2 / 12.75 meters
        val midEarthBulge = (distanceKm * distanceKm) / (8.0 * K_FACTOR * (EARTH_RADIUS_KM / 1000.0))

        // 1st Fresnel zone radius at midpoint: F1 = 17.32 * sqrt( (d1 * d2) / (f_GHz * D) )
        // With frequency in MHz: f_GHz = f_MHz / 1000
        val fGhz = frequencyMhz / 1000.0
        val d1Km = distanceKm / 2.0
        val d2Km = distanceKm / 2.0
        val fresnelMid = 17.32 * sqrt((d1Km * d2Km) / (fGhz * distanceKm))

        // LOS straight line height at midpoint (mean of both total heights)
        val losMidHeight = (totalHeight1 + totalHeight2) / 2.0

        // Terrain baseline at midpoint (interpolated ground elevation + earth curvature bulge)
        val interpolatedGroundMid = (p1Elevation + p2Elevation) / 2.0
        val obstacleMidHeight = interpolatedGroundMid + midEarthBulge

        // Clearance margin between LOS line and Earth/Terrain bulge
        val clearanceToEarth = losMidHeight - obstacleMidHeight

        // 60% Fresnel Zone clearance is required for unobstructed RF propagation
        val requiredClearance = fresnelMid * 0.6
        val netFresnelMargin = clearanceToEarth - requiredClearance

        val isClear = clearanceToEarth > fresnelMid
        val isMarginal = clearanceToEarth in 0.0..fresnelMid
        val isObstructed = clearanceToEarth < 0.0

        val (statusText, colorType, advice) = when {
            isClear -> Triple(
                "LINE OF SIGHT: ক্লিয়ার (CLEAR)",
                LosAnalysisResult.StatusColor.CLEAR,
                "উভয় এন্টেনার মাঝে সরাসরি দৃষ্টিরেখা (LOS) ও ৬০% ফ্রেনেল জোন সম্পূর্ণ ক্লিয়ার আছে। রেডিও সিগন্যাল সর্বোচ্চ দক্ষতায় প্রবাহিত হবে।"
            )
            isMarginal -> Triple(
                "LINE OF SIGHT: মার্জিনাল (FRESNEL TOUCH)",
                LosAnalysisResult.StatusColor.MARGINAL,
                "দৃষ্টিরেখা রয়েছে তবে ফ্রেনেল জোনের কিছু অংশ পৃথিবীর বক্রতা বা গাছপালায় স্পর্শ করতে পারে। এন্টেনার উচ্চতা আরও ${"%.1f".format(fresnelMid - clearanceToEarth)} মিটার বাড়ালে সেরা সিগন্যাল পাওয়া যাবে।"
            )
            else -> Triple(
                "LINE OF SIGHT: অবস্ট্রাকটেড / বাধাপ্রাপ্ত (BLOCKED)",
                LosAnalysisResult.StatusColor.OBSTRUCTED,
                "পৃথিবীর বক্রতা বা উচ্চতা পার্থক্যের কারণে সরাসরি লাইন অফ সাইড বাধাপ্রাপ্ত হচ্ছে! সংযোগ নিশ্চিত করতে অন্তত ${"%.1f".format(-clearanceToEarth + fresnelMid)} মিটার এন্টেনা উচ্চতা বাড়ানো প্রয়োজন।"
            )
        }

        // Generate 10-point cross-section profile for graphical plotting
        val profilePoints = mutableListOf<TerrainPoint>()
        val steps = 10
        for (i in 0..steps) {
            val frac = i.toFloat() / steps
            val d1 = distanceKm * frac
            val d2 = distanceKm * (1.0 - frac)
            val bulge = if (frac > 0 && frac < 1) (d1 * d2) / (2.0 * K_FACTOR * (EARTH_RADIUS_KM / 1000.0)) else 0.0
            val ground = p1Elevation + (p2Elevation - p1Elevation) * frac
            val losRay = totalHeight1 + (totalHeight2 - totalHeight1) * frac
            val fresnel = if (frac > 0 && frac < 1) 17.32 * sqrt((d1 * d2) / (fGhz * distanceKm)) else 0.0

            profilePoints.add(
                TerrainPoint(
                    distanceFraction = frac,
                    groundElevationMeters = ground,
                    earthBulgeMeters = bulge,
                    losBeamHeightMeters = losRay,
                    fresnelRadiusMeters = fresnel
                )
            )
        }

        return LosAnalysisResult(
            isLosClear = isClear,
            clearanceMarginMeters = clearanceToEarth,
            earthCurvatureBulgeMeters = midEarthBulge,
            fresnelZoneRadiusMeters = fresnelMid,
            statusText = statusText,
            statusColorType = colorType,
            recommendation = advice,
            points = profilePoints
        )
    }
}
