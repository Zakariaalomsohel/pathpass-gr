package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Height
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.ShareLocation
import com.example.data.model.CalculationResult
import com.example.data.model.DistanceUnit
import com.example.data.model.NavigationCalculator
import com.example.ui.MainViewModel
import com.example.ui.components.CompassRoseView
import com.example.ui.components.CreditDialog
import com.example.ui.components.LineOfSightView
import com.example.ui.components.TacticalRadarMapView

@Composable
fun CalculatorScreen(
    viewModel: MainViewModel,
    onNavigateToIntel: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToButm: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val p1Lat by viewModel.p1Lat.collectAsState()
    val p1Lon by viewModel.p1Lon.collectAsState()
    val p1Elevation by viewModel.p1Elevation.collectAsState()
    val p1ElevLoading by viewModel.p1ElevationLoading.collectAsState()

    val p2Lat by viewModel.p2Lat.collectAsState()
    val p2Lon by viewModel.p2Lon.collectAsState()
    val p2Elevation by viewModel.p2Elevation.collectAsState()
    val p2ElevLoading by viewModel.p2ElevationLoading.collectAsState()

    val calcResult by viewModel.calculationResult.collectAsState()
    val selectedUnit by viewModel.selectedUnit.collectAsState()
    val isGpsSearching by viewModel.isGpsSearching.collectAsState()

    val p1AntennaHeight by viewModel.p1AntennaHeight.collectAsState()
    val p2AntennaHeight by viewModel.p2AntennaHeight.collectAsState()
    val frequencyMhz by viewModel.frequencyMhz.collectAsState()
    val frequency2Mhz by viewModel.frequency2Mhz.collectAsState()

    val isOfflineCached by viewModel.isOfflineCached.collectAsState()
    val isCachingMap by viewModel.isCachingMap.collectAsState()
    val cachingProgress by viewModel.cachingProgress.collectAsState()
    val activeCachedArea by viewModel.activeCachedArea.collectAsState()

    var showCreditDialog by remember { mutableStateOf(false) }

    if (showCreditDialog) {
        CreditDialog(onDismiss = { showCreditDialog = false })
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1-Click Live Location Share Button
        Button(
            onClick = { viewModel.shareLiveLocation(context) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("share_live_location_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.ShareLocation, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("১-ক্লিকে লাইভ লোকেশন শেয়ার করুন (Share Live GPS)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // OFFLINE MAP CACHE QUICK TOGGLE STRIP
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isOfflineCached) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isOfflineCached) Icons.Default.CloudDone else Icons.Default.CloudDownload,
                        contentDescription = "Offline Cache",
                        tint = if (isOfflineCached) Color(0xFF10B981) else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isOfflineCached) "Offline Map Cache: ACTIVE" else "Cache Visible Area for Offline",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isOfflineCached) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isOfflineCached) "ইন্টারনেট ছাড়া রিমোট এরিয়ায় প্রস্তুত" else "রিমোট লোকেশনে ব্যবহারের জন্য টগল অন করুন",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Switch(
                    checked = isOfflineCached,
                    onCheckedChange = { viewModel.toggleOfflineCache(it) },
                    modifier = Modifier.testTag("calculator_offline_toggle"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF10B981)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Unit Selector & Header Tools
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "COORDINATE CALCULATOR",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DistanceUnit.values().forEach { unit ->
                    FilterChip(
                        selected = selectedUnit == unit,
                        onClick = { viewModel.setUnit(unit) },
                        label = { Text(unit.suffix, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // POINT 1 CARD (Observer / Start)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "First Location (Point 1 / Observer)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // My Location Button
                    Button(
                        onClick = { viewModel.setCurrentLocationAsPoint1() },
                        modifier = Modifier.testTag("loc_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        if (isGpsSearching) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        } else {
                            Icon(
                                Icons.Default.MyLocation,
                                contentDescription = "Get GPS Location",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "My GPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = p1Lat,
                        onValueChange = { viewModel.onP1LatChanged(it) },
                        label = { Text("Latitude (Lat 1)", fontSize = 12.sp) },
                        placeholder = { Text("e.g. 23.8103") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("editTextFirstLatitude"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = p1Lon,
                        onValueChange = { viewModel.onP1LonChanged(it) },
                        label = { Text("Longitude (Lon 1)", fontSize = 12.sp) },
                        placeholder = { Text("e.g. 90.4125") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("editTextFirstLongitude"),
                        singleLine = true
                    )
                }

                // Elevation Display for Point 1
                Spacer(modifier = Modifier.height(8.dp))
                ElevationBadge(
                    elevationMeters = p1Elevation,
                    isLoading = p1ElevLoading,
                    pointLabel = "Point 1"
                )
            }
        }

        // SWAP BUTTON
        Box(
            modifier = Modifier
                .padding(vertical = 4.dp)
                .size(36.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                .clickable { viewModel.swapPoints() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.SwapVert,
                contentDescription = "Swap Locations",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        // POINT 2 CARD (Target / Destination)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.error, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Second Location (Point 2 / Target)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onNavigateToIntel,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Search Place", style = MaterialTheme.typography.labelMedium)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = p2Lat,
                        onValueChange = { viewModel.onP2LatChanged(it) },
                        label = { Text("Latitude (Lat 2)", fontSize = 12.sp) },
                        placeholder = { Text("e.g. 24.3636") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("editTextSecondLatitude"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = p2Lon,
                        onValueChange = { viewModel.onP2LonChanged(it) },
                        label = { Text("Longitude (Lon 2)", fontSize = 12.sp) },
                        placeholder = { Text("e.g. 88.6241") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("editTextSecondLongitude"),
                        singleLine = true
                    )
                }

                // Elevation Display for Point 2
                Spacer(modifier = Modifier.height(8.dp))
                ElevationBadge(
                    elevationMeters = p2Elevation,
                    isLoading = p2ElevLoading,
                    pointLabel = "Point 2"
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // PRIMARY ACTION BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { viewModel.calculateDistance() },
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp)
                    .testTag("calc_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Calculate, contentDescription = "Calculate")
                Spacer(modifier = Modifier.width(8.dp))
                Text("হিসাব করুন (Calculate)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            OutlinedButton(
                onClick = { viewModel.clearAll() },
                modifier = Modifier
                    .weight(0.7f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Clear, contentDescription = "Clear")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clear")
            }
        }

        // CALCULATION RESULTS SECTION
        AnimatedVisibility(visible = calcResult != null) {
            calcResult?.let { result ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(18.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "CALCULATION REPORT",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Big Distance Readout
                            Text(
                                text = result.formatDistance(selectedUnit),
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("textViewDistance")
                            )

                            Text(
                                text = "Great-Circle Geodesic Distance",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Bearing Cards Row with Compass
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Forward Bearing
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "Forward Bearing",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${result.bearingRounded}°",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "${result.bearingCardinal} (${result.bearingMils} Mils)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                // Interactive Mini Compass Rose
                                CompassRoseView(
                                    bearingDegrees = result.bearingDegrees.toFloat(),
                                    backBearingDegrees = result.backBearingDegrees.toFloat(),
                                    modifier = Modifier.size(130.dp)
                                )

                                // Back Bearing
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "Back Bearing",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${result.backBearingRounded}°",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(
                                        text = "${result.backBearingCardinal} (${result.backBearingMils} Mils)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }

                            // Elevation Difference and Incline Analysis
                            if (p1Elevation != null && p2Elevation != null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                val delta = p2Elevation!! - p1Elevation!!
                                val (gradePercent, slopeAngle) = NavigationCalculator.calculateSlope(result.distanceMeters, delta)
                                val deltaSign = if (delta > 0) "+" else ""

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceAround
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("উচ্চতার ব্যবধান (Δh)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                "$deltaSign${"%.1f".format(delta)} m (${deltaSign}${"%.1f".format(delta * 3.28084)} ft)",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (delta >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                            )
                                        }

                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("ঢাল / গ্রেডিয়েন্ট", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                "${"%.2f".format(gradePercent)}% (${"%.2f".format(slopeAngle)}°)",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.tertiary
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action buttons: SMS, Share, Save, AI
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { sendSms(context, result) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("msg_button"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "SMS", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("SMS", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { shareReport(context, result) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.saveRoute() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.BookmarkAdd, contentDescription = "Save", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Save", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = onNavigateToIntel,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("AI Intel", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Embedded Tactical Radar Map
                    TacticalRadarMapView(
                        calcResult = result,
                        p1Elevation = p1Elevation,
                        p2Elevation = p2Elevation,
                        isOfflineCached = isOfflineCached,
                        isCachingMap = isCachingMap,
                        cachingProgress = cachingProgress,
                        activeCachedArea = activeCachedArea,
                        onToggleOfflineCache = { viewModel.toggleOfflineCache(it) },
                        onCacheVisibleArea = { viewModel.cacheVisibleMapArea() },
                        onClearOfflineCache = { viewModel.clearOfflineCache() }
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Antenna Heights & Line of Sight (LOS) / Fresnel Zone Analysis
                    LineOfSightView(
                        calcResult = result,
                        p1Elevation = p1Elevation,
                        p2Elevation = p2Elevation,
                        p1AntennaHeight = p1AntennaHeight,
                        onP1AntennaHeightChange = { viewModel.setP1AntennaHeight(it) },
                        p2AntennaHeight = p2AntennaHeight,
                        onP2AntennaHeightChange = { viewModel.setP2AntennaHeight(it) },
                        frequencyMhz = frequencyMhz,
                        onFrequencyChange = { viewModel.setFrequencyMhz(it) },
                        frequency2Mhz = frequency2Mhz,
                        onFrequency2Change = { viewModel.setFrequency2Mhz(it) },
                        onScanObstaclesGemini = {
                            viewModel.scanObstaclesWithGemini()
                            onNavigateToIntel()
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Military Developer Credit (as requested in original code)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showCreditDialog = true }
                .padding(vertical = 12.dp)
                .testTag("credit_text"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = "Credit",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Developed By : 1618101 Cpl (Tech) Md Zakaria Alom, 3 Sigbn",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }
                Text(
                    text = "Tap to view developer credit & unit specifications",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun ElevationBadge(
    elevationMeters: Double?,
    isLoading: Boolean,
    pointLabel: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Terrain,
                    contentDescription = "Elevation",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.tertiary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "সমুদ্রপৃষ্ঠ থেকে উচ্চতা (Elevation):",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isLoading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("যাচাই হচ্ছে...", style = MaterialTheme.typography.labelSmall)
                }
            } else if (elevationMeters != null) {
                val feet = elevationMeters * 3.28084
                Text(
                    text = "${"%.1f".format(elevationMeters)} মি (${"%.1f".format(feet)} ফুট)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                Text(
                    text = "Lat/Lon লিখলে স্বয়ংক্রিয় বের হবে",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

private fun sendSms(context: Context, result: CalculationResult) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            type = "vnd.android-dir/mms-sms"
            putExtra("sms_body", result.toSmsBody())
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        val sendIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", result.toSmsBody())
        }
        try {
            context.startActivity(sendIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "SMS অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun shareReport(context: Context, result: CalculationResult) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, result.toDetailedReport())
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Share Location Finder Report")
    context.startActivity(shareIntent)
}
