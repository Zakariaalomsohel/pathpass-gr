package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forest
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CalculationResult
import com.example.data.model.KmlExporter
import com.example.data.model.LosAnalysisResult
import com.example.data.model.LosCalculator

@Composable
fun LineOfSightView(
    calcResult: CalculationResult?,
    p1Elevation: Double?,
    p2Elevation: Double?,
    p1AntennaHeight: String,
    onP1AntennaHeightChange: (String) -> Unit,
    p2AntennaHeight: String,
    onP2AntennaHeightChange: (String) -> Unit,
    frequencyMhz: Double,
    onFrequencyChange: (Double) -> Unit,
    frequency2Mhz: Double = 5800.0,
    onFrequency2Change: (Double) -> Unit = {},
    modifier: Modifier = Modifier,
    onScanObstaclesGemini: () -> Unit = {}
) {
    val context = LocalContext.current

    // Antenna heights
    val h1 = p1AntennaHeight.toDoubleOrNull() ?: 15.0
    val h2 = p2AntennaHeight.toDoubleOrNull() ?: 15.0
    val elev1 = p1Elevation ?: 15.0
    val elev2 = p2Elevation ?: 15.0

    // Geodesic distance taken directly from calculator (Range input removed as requested)
    val activeDistKm = if (calcResult != null) calcResult.distanceMeters / 1000.0 else 10.0
    var customFreq1Text by remember(frequencyMhz) { mutableStateOf(frequencyMhz.toInt().toString()) }
    var customFreq2Text by remember(frequency2Mhz) { mutableStateOf(frequency2Mhz.toInt().toString()) }
    var showDigitalProfileTable by remember { mutableStateOf(false) }

    val activeFreq1Mhz = customFreq1Text.toDoubleOrNull() ?: frequencyMhz
    val activeFreq2Mhz = customFreq2Text.toDoubleOrNull() ?: frequency2Mhz

    val losResult = LosCalculator.calculateLineOfSight(
        distanceKm = activeDistKm,
        p1Elevation = elev1,
        p1AntennaHeight = h1,
        p2Elevation = elev2,
        p2AntennaHeight = h2,
        frequencyMhz = activeFreq1Mhz
    )

    val losResult2 = LosCalculator.calculateLineOfSight(
        distanceKm = activeDistKm,
        p1Elevation = elev1,
        p1AntennaHeight = h1,
        p2Elevation = elev2,
        p2AntennaHeight = h2,
        frequencyMhz = activeFreq2Mhz
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CellTower,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "RF LINE OF SIGHT (LOS)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = "১ম ফ্রেনেল জোন ও ডিজিটাল পাথ প্রোফাইল (দূরত্ব: ${"%.2f".format(activeDistKm)} KM)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Antenna Height Inputs for Terminal 1 and Terminal 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = p1AntennaHeight,
                    onValueChange = onP1AntennaHeightChange,
                    label = { Text("P1 এন্টেনা (Site A Mast)", fontSize = 11.sp) },
                    placeholder = { Text("15") },
                    suffix = { Text("মি", fontWeight = FontWeight.Bold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("p1_antenna_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = p2AntennaHeight,
                    onValueChange = onP2AntennaHeightChange,
                    label = { Text("P2 এন্টেনা (Site B Mast)", fontSize = 11.sp) },
                    placeholder = { Text("15") },
                    suffix = { Text("মি", fontWeight = FontWeight.Bold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("p2_antenna_input"),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // TWO DUAL FREQUENCY INPUT BOXES (SPECIFICALLY REQUESTED: দুইটি ফ্রিকুয়েন্সী দেওয়ার ঘর)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customFreq1Text,
                    onValueChange = {
                        customFreq1Text = it
                        it.toDoubleOrNull()?.let { f -> onFrequencyChange(f) }
                    },
                    label = { Text("ফ্রিকুয়েন্সী ১ (Freq 1 / Tx)", fontSize = 11.sp) },
                    placeholder = { Text("400") },
                    suffix = { Text("MHz", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("frequency_input_1"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = customFreq2Text,
                    onValueChange = {
                        customFreq2Text = it
                        it.toDoubleOrNull()?.let { f -> onFrequency2Change(f) }
                    },
                    label = { Text("ফ্রিকুয়েন্সী ২ (Freq 2 / Rx)", fontSize = 11.sp) },
                    placeholder = { Text("5800") },
                    suffix = { Text("MHz", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f).testTag("frequency_input_2"),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Preset Frequency quick chips for Freq 1 & Freq 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ফ্রিকুয়েন্সী প্রিসেট:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        Pair("150M", 150.0),
                        Pair("400M", 400.0),
                        Pair("2.4G", 2400.0),
                        Pair("5.8G", 5800.0)
                    ).forEach { (label, freq) ->
                        FilterChip(
                            selected = activeFreq1Mhz == freq,
                            onClick = {
                                customFreq1Text = freq.toInt().toString()
                                onFrequencyChange(freq)
                            },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // DUAL 1st FRESNEL ZONE ANALYSIS SUMMARY CARD (COMPARING BOTH FREQUENCIES)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "১ম ফ্রেনেল জোন তুলনা (Fresnel Zone Comparison)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Earth Bulge: ${"%.1f".format(losResult.earthCurvatureBulgeMeters)} মি",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // FREQ 1 ROW
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Freq 1: ${activeFreq1Mhz.toInt()} MHz",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "স্ট্যাটাস: ${losResult.statusText}",
                                style = MaterialTheme.typography.labelSmall,
                                color = when (losResult.statusColorType) {
                                    LosAnalysisResult.StatusColor.CLEAR -> Color(0xFF10B981)
                                    LosAnalysisResult.StatusColor.MARGINAL -> Color(0xFFF59E0B)
                                    LosAnalysisResult.StatusColor.OBSTRUCTED -> MaterialTheme.colorScheme.error
                                }
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "F₁: ${"%.1f".format(losResult.fresnelZoneRadiusMeters)} মি (${"%.1f".format(losResult.fresnelZoneRadiusMeters * 3.28084)} ফুট)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "৬০% মার্জিন: ${"%.1f".format(losResult.fresnelZoneRadiusMeters * 0.6)} মি",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // FREQ 2 ROW
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Freq 2: ${activeFreq2Mhz.toInt()} MHz",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "স্ট্যাটাস: ${losResult2.statusText}",
                                style = MaterialTheme.typography.labelSmall,
                                color = when (losResult2.statusColorType) {
                                    LosAnalysisResult.StatusColor.CLEAR -> Color(0xFF10B981)
                                    LosAnalysisResult.StatusColor.MARGINAL -> Color(0xFFF59E0B)
                                    LosAnalysisResult.StatusColor.OBSTRUCTED -> MaterialTheme.colorScheme.error
                                }
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "F₁: ${"%.1f".format(losResult2.fresnelZoneRadiusMeters)} মি (${"%.1f".format(losResult2.fresnelZoneRadiusMeters * 3.28084)} ফুট)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "৬০% মার্জিন: ${"%.1f".format(losResult2.fresnelZoneRadiusMeters * 0.6)} মি",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2D ELEVATION PROFILE & FRESNEL ZONE CANVAS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFF090E17), RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    val w = size.width
                    val h = size.height
                    val paddingBottom = 28f
                    val paddingTop = 24f
                    val drawH = h - paddingBottom - paddingTop

                    val siteAX = 40f
                    val siteBX = w - 40f

                    val maxVal = maxOf(
                        elev1 + h1,
                        elev2 + h2,
                        (elev1 + elev2) / 2.0 + losResult.earthCurvatureBulgeMeters + losResult.fresnelZoneRadiusMeters
                    ) + 15.0
                    val minVal = minOf(elev1, elev2, 0.0)
                    val range = maxOf(maxVal - minVal, 1.0)

                    fun getY(valMeters: Double): Float {
                        val norm = ((valMeters - minVal) / range).toFloat()
                        return h - paddingBottom - (norm * drawH)
                    }

                    val groundA_Y = getY(elev1)
                    val mastA_Y = getY(elev1 + h1)
                    val groundB_Y = getY(elev2)
                    val mastB_Y = getY(elev2 + h2)

                    // Draw Curved Earth Surface / Terrain line
                    val terrainPath = Path().apply {
                        moveTo(siteAX, groundA_Y)
                        val midX = (siteAX + siteBX) / 2f
                        val midGround = (elev1 + elev2) / 2.0 + losResult.earthCurvatureBulgeMeters
                        val midY = getY(midGround)
                        quadraticTo(midX, midY, siteBX, groundB_Y)
                    }
                    drawPath(
                        path = terrainPath,
                        color = Color(0xFF64748B),
                        style = Stroke(width = 3f)
                    )

                    // Draw 1st Fresnel Zone Ellipse
                    val losBeamMidY = (mastA_Y + mastB_Y) / 2f
                    val fresnelHalfH = (losResult.fresnelZoneRadiusMeters / range * drawH).toFloat()
                    val ellipsePath = Path().apply {
                        moveTo(siteAX, mastA_Y)
                        cubicTo(
                            siteAX + (siteBX - siteAX) * 0.35f, losBeamMidY - fresnelHalfH,
                            siteAX + (siteBX - siteAX) * 0.65f, losBeamMidY - fresnelHalfH,
                            siteBX, mastB_Y
                        )
                        cubicTo(
                            siteAX + (siteBX - siteAX) * 0.65f, losBeamMidY + fresnelHalfH,
                            siteAX + (siteBX - siteAX) * 0.35f, losBeamMidY + fresnelHalfH,
                            siteAX, mastA_Y
                        )
                        close()
                    }
                    val fresnelColor = if (losResult.isLosClear) Color(0x3310B981) else Color(0x33EF4444)
                    drawPath(path = ellipsePath, color = fresnelColor)

                    // Draw Direct Line of Sight (LOS) Ray
                    val rayColor = when (losResult.statusColorType) {
                        LosAnalysisResult.StatusColor.CLEAR -> Color(0xFF10B981)
                        LosAnalysisResult.StatusColor.MARGINAL -> Color(0xFFF59E0B)
                        LosAnalysisResult.StatusColor.OBSTRUCTED -> Color(0xFFEF4444)
                    }
                    drawLine(
                        color = rayColor,
                        start = Offset(siteAX, mastA_Y),
                        end = Offset(siteBX, mastB_Y),
                        strokeWidth = 3.5f,
                        cap = StrokeCap.Round
                    )

                    // Draw Site A Tower
                    drawLine(color = Color.White, start = Offset(siteAX, groundA_Y), end = Offset(siteAX, mastA_Y), strokeWidth = 4f)
                    drawCircle(color = Color(0xFF10B981), radius = 6f, center = Offset(siteAX, mastA_Y))

                    // Draw Site B Tower
                    drawLine(color = Color.White, start = Offset(siteBX, groundB_Y), end = Offset(siteBX, mastB_Y), strokeWidth = 4f)
                    drawCircle(color = Color(0xFFEF4444), radius = 6f, center = Offset(siteBX, mastB_Y))

                    // Labels on Canvas
                    drawContext.canvas.nativeCanvas.apply {
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.WHITE
                            textSize = 22f
                            isFakeBoldText = true
                        }
                        paint.textAlign = android.graphics.Paint.Align.LEFT
                        drawText("Site A (${h1.toInt()}m)", siteAX - 20f, mastA_Y - 10f, paint)

                        paint.textAlign = android.graphics.Paint.Align.RIGHT
                        drawText("Site B (${h2.toInt()}m)", siteBX + 20f, mastB_Y - 10f, paint)

                        // Midpoint Clearance info
                        paint.textAlign = android.graphics.Paint.Align.CENTER
                        val midX = (siteAX + siteBX) / 2f
                        paint.color = if (losResult.isLosClear) android.graphics.Color.GREEN else android.graphics.Color.RED
                        val clearanceSign = if (losResult.clearanceMarginMeters >= 0) "+" else ""
                        drawText(
                            "Net Clearance: $clearanceSign${"%.1f".format(losResult.clearanceMarginMeters)}m",
                            midX,
                            losBeamMidY - fresnelHalfH - 8f,
                            paint
                        )

                        paint.color = android.graphics.Color.GRAY
                        paint.textSize = 20f
                        drawText("Range: ${"%.1f".format(activeDistKm)} km | Bulge: ${"%.1f".format(losResult.earthCurvatureBulgeMeters)}m", midX, h - 6f, paint)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // STATUS BANNER
            val statusBg = when (losResult.statusColorType) {
                LosAnalysisResult.StatusColor.CLEAR -> Color(0xFF064E3B)
                LosAnalysisResult.StatusColor.MARGINAL -> Color(0xFF78350F)
                LosAnalysisResult.StatusColor.OBSTRUCTED -> Color(0xFF7F1D1D)
            }
            val statusBorder = when (losResult.statusColorType) {
                LosAnalysisResult.StatusColor.CLEAR -> Color(0xFF10B981)
                LosAnalysisResult.StatusColor.MARGINAL -> Color(0xFFF59E0B)
                LosAnalysisResult.StatusColor.OBSTRUCTED -> Color(0xFFEF4444)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(statusBg, RoundedCornerShape(10.dp))
                    .border(1.dp, statusBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = if (losResult.isLosClear) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = statusBorder,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = losResult.statusText,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = losResult.recommendation,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // DIGITAL PATH PROFILE TABLE TOGGLE
            OutlinedButton(
                onClick = { showDigitalProfileTable = !showDigitalProfileTable },
                modifier = Modifier.fillMaxWidth().testTag("toggle_digital_profile_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (showDigitalProfileTable) "ডিজিটাল পাথ প্রোফাইল লুকান (Hide Profile)" else "ডিজিটাল পাথ প্রোফাইল টেবিল দেখুন (View Digital Profile)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            AnimatedVisibility(visible = showDigitalProfileTable) {
                Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(
                        text = "DIGITAL PATH PROFILE INTERVALS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            // Table Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("দূরত্ব", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text("ভূমি (m)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                Text("বাল্জ (m)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                Text("LOS রে", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                Text("ক্লিয়ারেন্স", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            // 5 key checkpoints along path: 0%, 25%, 50%, 75%, 100%
                            listOf(0.0f, 0.25f, 0.50f, 0.75f, 1.0f).forEach { frac ->
                                val dFromA = activeDistKm * frac
                                val d1 = dFromA
                                val d2 = activeDistKm * (1.0 - frac)
                                val bulge = if (frac > 0 && frac < 1) (d1 * d2) / 12.75 else 0.0
                                val ground = elev1 + (elev2 - elev1) * frac
                                val ray = (elev1 + h1) + ((elev2 + h2) - (elev1 + h1)) * frac
                                val clear = ray - (ground + bulge)
                                val clearColor = if (clear > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${"%.1f".format(dFromA)}k", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Text("${"%.0f".format(ground)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                    Text("${"%.1f".format(bulge)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                    Text("${"%.0f".format(ray)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                                    Text(
                                        "${if (clear > 0) "+" else ""}${"%.1f".format(clear)}m",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = clearColor,
                                        modifier = Modifier.weight(1f),
                                        textAlign = TextAlign.End
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3D GOOGLE EARTH & ARCGIS EARTH EXTRACT BUTTONS
            Text(
                text = "গুগল আর্থ ও ARCGIS EARTH এক্সট্র্যাক্ট",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "দুইটি টার্মিনালের ৩ডি লাইন অফ সাইড সরাসরি এক্সট্র্যাক্ট করে দেখুন",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Primary Extract Button for Google Earth & ArcGIS Earth (3D KML)
            Button(
                onClick = {
                    KmlExporter.exportAndLaunchKml(
                        context = context,
                        calcResult = calcResult,
                        p1Elevation = elev1,
                        p1AntennaHeight = h1,
                        p2Elevation = elev2,
                        p2AntennaHeight = h2,
                        frequencyMhz = activeFreqMhz,
                        losResult = losResult
                    )
                },
                modifier = Modifier.fillMaxWidth().testTag("export_kml_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Google Earth ও ArcGIS এ 3D Extract করুন (KML)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Secondary Quick 3D Web Launchers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val lat1 = calcResult?.point1?.latitude ?: 23.8103
                        val lon1 = calcResult?.point1?.longitude ?: 90.4125
                        openGoogleEarthWeb(context, lat1, lon1)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Earth 3D Web", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val lat1 = calcResult?.point1?.latitude ?: 23.8103
                        val lon1 = calcResult?.point1?.longitude ?: 90.4125
                        openArcGisEarthWeb(context, lat1, lon1)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Terrain, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ArcGIS 3D Web", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        KmlExporter.shareKmlFile(
                            context = context,
                            calcResult = calcResult,
                            p1Elevation = elev1,
                            p1AntennaHeight = h1,
                            p2Elevation = elev2,
                            p2AntennaHeight = h2,
                            frequencyMhz = activeFreqMhz,
                            losResult = losResult
                        )
                    },
                    modifier = Modifier.weight(0.7f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share KML", modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Gemini 3.8 Maps Obstacle Scanner (Mountains, Buildings & Dense Jungle)
            Button(
                onClick = onScanObstaclesGemini,
                modifier = Modifier.fillMaxWidth().testTag("scan_obstacles_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Forest, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("পাহাড়, বিল্ডিং ও ঘন জঙ্গল স্ক্যান রিপোর্ট (AI Scan)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

private fun openGoogleEarthWeb(context: Context, lat: Double, lon: Double) {
    try {
        val uri = Uri.parse("https://earth.google.com/web/@$lat,$lon,600a,35y,0h,60t,0r")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    } catch (_: Exception) {
        val webUri = Uri.parse("https://earth.google.com/web/@$lat,$lon,600a")
        context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
    }
}

private fun openArcGisEarthWeb(context: Context, lat: Double, lon: Double) {
    try {
        val uri = Uri.parse("https://www.arcgis.com/home/webscene/viewer.html?viewpoint=cam:$lon,$lat,1500;0;45")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (_: Exception) {
        val webUri = Uri.parse("https://www.arcgis.com/home/webscene/viewer.html")
        context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
    }
}
