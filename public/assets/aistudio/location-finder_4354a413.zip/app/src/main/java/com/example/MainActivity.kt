package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Grid4x4
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.ShareLocation
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.MainViewModel
import com.example.ui.components.CreditDialog
import com.example.ui.components.LineOfSightView
import com.example.ui.components.TacticalRadarMapView
import com.example.ui.components.TopDeveloperBanner
import com.example.ui.screens.ButmConverterScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.GeminiIntelScreen
import com.example.ui.screens.SavedRoutesScreen
import com.example.ui.screens.StandaloneCompassScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

enum class AppScreen(val title: String) {
    CALCULATOR("Calculator"),
    RADAR("Radar & LOS"),
    BUTM("BUTM Grid"),
    COMPASS("Compass"),
    INTEL("Maps Intel"),
    SAVED("Saved Routes")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(AppScreen.CALCULATOR) }
    var showCreditDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val userMessage by viewModel.userMessage.collectAsState()

    // Location Permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            viewModel.fetchGpsFix(silent = false)
        } else {
            Toast.makeText(context, "Location permission required", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // Handle user messages
    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearMessage()
            }
        }
    }

    // Back handling for custom navigation
    BackHandler(enabled = currentScreen != AppScreen.CALCULATOR) {
        currentScreen = AppScreen.CALCULATOR
    }

    if (showCreditDialog) {
        CreditDialog(onDismiss = { showCreditDialog = false })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "LOCATION FINDER",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                actions = {
                    // Quick 1-click location share button in top bar
                    IconButton(
                        onClick = { viewModel.shareLiveLocation(context) },
                        modifier = Modifier.testTag("top_share_location_button")
                    ) {
                        Icon(
                            Icons.Default.ShareLocation,
                            contentDescription = "Share Live Location",
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    IconButton(
                        onClick = { viewModel.fetchGpsFix(silent = false) },
                        modifier = Modifier.testTag("gps_refresh_button")
                    ) {
                        Icon(
                            Icons.Default.MyLocation,
                            contentDescription = "Refresh GPS",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = { showCreditDialog = true },
                        modifier = Modifier.testTag("credit_button")
                    ) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = "Developer Credit",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.CALCULATOR,
                    onClick = { currentScreen = AppScreen.CALCULATOR },
                    icon = { Icon(Icons.Default.Calculate, contentDescription = "Calculator") },
                    label = { Text("Calc", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.RADAR,
                    onClick = { currentScreen = AppScreen.RADAR },
                    icon = { Icon(Icons.Default.Radar, contentDescription = "Radar & LOS") },
                    label = { Text("Radar/LOS", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.COMPASS,
                    onClick = { currentScreen = AppScreen.COMPASS },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Compass") },
                    label = { Text("Compass", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.INTEL,
                    onClick = { currentScreen = AppScreen.INTEL },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Maps Intel") },
                    label = { Text("AI Intel", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.SAVED,
                    onClick = { currentScreen = AppScreen.SAVED },
                    icon = { Icon(Icons.Default.Bookmarks, contentDescription = "Saved") },
                    label = { Text("Saved", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // PROMINENT TOP DEVELOPER BANNER (Slides up from bottom to top as requested)
            TopDeveloperBanner(
                onClick = { showCreditDialog = true }
            )

            Box(modifier = Modifier.fillMaxSize().weight(1f)) {
                when (currentScreen) {
                    AppScreen.CALCULATOR -> {
                        CalculatorScreen(
                            viewModel = viewModel,
                            onNavigateToIntel = { currentScreen = AppScreen.INTEL },
                            onNavigateToHistory = { currentScreen = AppScreen.SAVED }
                        )
                    }
                    AppScreen.RADAR -> {
                        val calcResult by viewModel.calculationResult.collectAsState()
                        val p1Elev by viewModel.p1Elevation.collectAsState()
                        val p2Elev by viewModel.p2Elevation.collectAsState()
                        val p1AntennaHeight by viewModel.p1AntennaHeight.collectAsState()
                        val p2AntennaHeight by viewModel.p2AntennaHeight.collectAsState()
                        val frequencyMhz by viewModel.frequencyMhz.collectAsState()
                        val frequency2Mhz by viewModel.frequency2Mhz.collectAsState()
                        val isOfflineCached by viewModel.isOfflineCached.collectAsState()
                        val isCachingMap by viewModel.isCachingMap.collectAsState()
                        val cachingProgress by viewModel.cachingProgress.collectAsState()
                        val activeCachedArea by viewModel.activeCachedArea.collectAsState()
                        val radarScrollState = rememberScrollState()

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(radarScrollState)
                                .padding(16.dp)
                        ) {
                            TacticalRadarMapView(
                                calcResult = calcResult,
                                p1Elevation = p1Elev,
                                p2Elevation = p2Elev,
                                isOfflineCached = isOfflineCached,
                                isCachingMap = isCachingMap,
                                cachingProgress = cachingProgress,
                                activeCachedArea = activeCachedArea,
                                onToggleOfflineCache = { viewModel.toggleOfflineCache(it) },
                                onCacheVisibleArea = { viewModel.cacheVisibleMapArea() },
                                onClearOfflineCache = { viewModel.clearOfflineCache() }
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            LineOfSightView(
                                calcResult = calcResult,
                                p1Elevation = p1Elev,
                                p2Elevation = p2Elev,
                                p1AntennaHeight = p1AntennaHeight,
                                onP1AntennaHeightChange = { viewModel.setP1AntennaHeight(it) },
                                p2AntennaHeight = p2AntennaHeight,
                                onP2AntennaHeightChange = { viewModel.setP2AntennaHeight(it) },
                                frequencyMhz = frequencyMhz,
                                onFrequencyChange = { viewModel.setFrequencyMhz(it) },
                                frequency2Mhz = frequency2Mhz,
                                onFrequency2Change = { viewModel.setFrequency2Mhz(it) },
                                onScanObstaclesGemini = {
                                    viewModel.scanObstaclesWithGemini()
                                    currentScreen = AppScreen.INTEL
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                    AppScreen.COMPASS -> {
                        StandaloneCompassScreen(viewModel = viewModel)
                    }
                    AppScreen.INTEL -> {
                        GeminiIntelScreen(
                            viewModel = viewModel,
                            onNavigateBackToCalc = { currentScreen = AppScreen.CALCULATOR }
                        )
                    }
                    AppScreen.SAVED -> {
                        SavedRoutesScreen(
                            viewModel = viewModel,
                            onNavigateBackToCalc = { currentScreen = AppScreen.CALCULATOR }
                        )
                    }
                }
            }
        }
    }
}
