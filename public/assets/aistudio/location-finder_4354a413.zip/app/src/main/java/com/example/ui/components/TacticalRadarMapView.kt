package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CachedMapAreaEntity
import com.example.data.model.CalculationResult
import com.example.data.model.DistanceUnit
import com.example.data.model.OfflineCacheProgress
import com.example.data.model.OfflineMapManager
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

enum class RadarMapMode {
    VECTOR_RADAR,
    OFFLINE_MAP
}

@Composable
fun TacticalRadarMapView(
    calcResult: CalculationResult?,
    p1Elevation: Double?,
    p2Elevation: Double?,
    isOfflineCached: Boolean = false,
    isCachingMap: Boolean = false,
    cachingProgress: OfflineCacheProgress? = null,
    activeCachedArea: CachedMapAreaEntity? = null,
    onToggleOfflineCache: (Boolean) -> Unit = {},
    onCacheVisibleArea: () -> Unit = {},
    onClearOfflineCache: () -> Unit = {},
    modifier: Modifier = Modifier,
    onOpenInGoogleMaps: () -> Unit = {}
) {
    val context = LocalContext.current
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    var currentMode by remember { mutableStateOf(RadarMapMode.VECTOR_RADAR) }
    var offlineZoom by remember { mutableIntStateOf(13) }

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary
    val errorColor = MaterialTheme.colorScheme.error
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant
    val borderColor = MaterialTheme.colorScheme.outline

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TACTICAL RADAR & MAP",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )
                    Text(
                        text = "Geodetic Line-of-Sight & Offline GIS Cache",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status chip
                Box(
                    modifier = Modifier
                        .background(
                            if (isOfflineCached) Color(0xFF10B981).copy(alpha = 0.2f) else primaryColor.copy(alpha = 0.15f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isOfflineCached) "OFFLINE READY" else "ONLINE / GPS",
                        color = if (isOfflineCached) Color(0xFF10B981) else primaryColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // OFFLINE MAP CACHE TOGGLE CONTROL BOX
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isOfflineCached) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ),
                border = if (isOfflineCached) CardDefaults.outlinedCardBorder() else null
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isOfflineCached) Icons.Default.CloudDone else Icons.Default.CloudDownload,
                                contentDescription = "Offline Cache",
                                tint = if (isOfflineCached) Color(0xFF10B981) else primaryColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Cache Visible Map Area (অফলাইন ক্যাশ)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isOfflineCached)
                                        "🟢 এরিয়া অফলাইনে ক্যাশ করা হয়েছে (রিমোট ব্যবহারের জন্য প্রস্তুত)"
                                    else
                                        "ইন্টারনেটহীন রিমোট এরিয়ায় ব্যবহারের জন্য ক্যাশ অন করুন",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Master Toggle Switch
                        Switch(
                            checked = isOfflineCached,
                            onCheckedChange = { onToggleOfflineCache(it) },
                            modifier = Modifier.testTag("offline_cache_toggle"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF10B981),
                                uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }

                    // Download Progress Indicator
                    AnimatedVisibility(visible = isCachingMap && cachingProgress != null) {
                        cachingProgress?.let { prog ->
                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                LinearProgressIndicator(
                                    progress = { prog.progress },
                                    modifier = Modifier.fillMaxWidth().height(6.dp),
                                    color = primaryColor
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = prog.currentStep,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = primaryColor
                                    )
                                    Text(
                                        text = "${(prog.progress * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryColor
                                    )
                                }
                            }
                        }
                    }

                    // Cached Area Info & Clear Action
                    if (isOfflineCached && activeCachedArea != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📦 ${activeCachedArea.name} (${activeCachedArea.tileCount} Tiles, ${activeCachedArea.elevationPointCount} DEM Points)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedButton(
                                onClick = onClearOfflineCache,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Clear Cache", modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mode Selector: Vector Radar vs Offline Tactical Map
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = currentMode == RadarMapMode.VECTOR_RADAR,
                        onClick = { currentMode = RadarMapMode.VECTOR_RADAR },
                        leadingIcon = {
                            Icon(Icons.Default.Radar, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text("Vector Radar", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = primaryColor,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )

                    FilterChip(
                        selected = currentMode == RadarMapMode.OFFLINE_MAP,
                        onClick = { currentMode = RadarMapMode.OFFLINE_MAP },
                        leadingIcon = {
                            Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text("Offline Map View", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = tertiaryColor,
                            selectedLabelColor = MaterialTheme.colorScheme.onTertiary,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onTertiary
                        )
                    )
                }

                // Zoom controls when in offline map mode
                if (currentMode == RadarMapMode.OFFLINE_MAP) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (offlineZoom > 11) offlineZoom-- },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(16.dp))
                        }
                        Text("Z$offlineZoom", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        IconButton(
                            onClick = { if (offlineZoom < 15) offlineZoom++ },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Zoom In", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // MAIN VISUALIZER CANVAS (Radar or Offline Map)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
                    .background(Color(0xFF070B12), RoundedCornerShape(12.dp))
                    .border(1.dp, borderColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (currentMode == RadarMapMode.VECTOR_RADAR) {
                    // VECTOR RADAR CANVAS
                    Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                        val w = size.width
                        val h = size.height
                        val center = Offset(w / 2f, h / 2f)
                        val maxR = minOf(w, h) / 2f - 10f

                        // Concentric Radar Rings
                        val ringSteps = 4
                        for (i in 1..ringSteps) {
                            val r = maxR * (i.toFloat() / ringSteps)
                            drawCircle(
                                color = primaryColor.copy(alpha = 0.2f),
                                radius = r,
                                center = center,
                                style = Stroke(width = 1.2f)
                            )
                        }

                        // Crosshair axis lines
                        drawLine(
                            color = primaryColor.copy(alpha = 0.25f),
                            start = Offset(center.x, center.y - maxR),
                            end = Offset(center.x, center.y + maxR),
                            strokeWidth = 1.2f
                        )
                        drawLine(
                            color = primaryColor.copy(alpha = 0.25f),
                            start = Offset(center.x - maxR, center.y),
                            end = Offset(center.x + maxR, center.y),
                            strokeWidth = 1.2f
                        )

                        // Diagonal 45-degree guide lines
                        val diagOffset = maxR * 0.7071f
                        drawLine(
                            color = primaryColor.copy(alpha = 0.12f),
                            start = Offset(center.x - diagOffset, center.y - diagOffset),
                            end = Offset(center.x + diagOffset, center.y + diagOffset),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = primaryColor.copy(alpha = 0.12f),
                            start = Offset(center.x - diagOffset, center.y + diagOffset),
                            end = Offset(center.x + diagOffset, center.y - diagOffset),
                            strokeWidth = 1f
                        )

                        // Cardinal points labels
                        drawContext.canvas.nativeCanvas.apply {
                            val p = android.graphics.Paint().apply {
                                color = android.graphics.Color.WHITE
                                textSize = 28f
                                textAlign = android.graphics.Paint.Align.CENTER
                                isFakeBoldText = true
                            }
                            p.color = android.graphics.Color.RED
                            drawText("N", center.x, center.y - maxR + 24f, p)
                            p.color = android.graphics.Color.GRAY
                            drawText("S", center.x, center.y + maxR - 8f, p)
                            drawText("E", center.x + maxR - 16f, center.y + 10f, p)
                            drawText("W", center.x - maxR + 16f, center.y + 10f, p)
                        }

                        if (calcResult != null) {
                            val bearingRad = Math.toRadians(calcResult.bearingDegrees)
                            val targetDistFraction = 0.75f
                            val targetR = maxR * targetDistFraction

                            val p2X = center.x + targetR * sin(bearingRad).toFloat()
                            val p2Y = center.y - targetR * cos(bearingRad).toFloat()
                            val targetPos = Offset(p2X, p2Y)

                            // Pulsing wave from Observer P1
                            drawCircle(
                                color = primaryColor.copy(alpha = 0.35f),
                                radius = pulseRadius,
                                center = center,
                                style = Stroke(width = 2f)
                            )

                            // Track line from P1 to P2
                            drawLine(
                                color = tertiaryColor,
                                start = center,
                                end = targetPos,
                                strokeWidth = 3f,
                                cap = StrokeCap.Round
                            )

                            // Target Arrowhead at P2
                            val angle = atan2(targetPos.y - center.y, targetPos.x - center.x)
                            val arrowLen = 22f
                            val arrowAngle = Math.toRadians(25.0)
                            val x1 = targetPos.x - arrowLen * cos(angle - arrowAngle).toFloat()
                            val y1 = targetPos.y - arrowLen * sin(angle - arrowAngle).toFloat()
                            val x2 = targetPos.x - arrowLen * cos(angle + arrowAngle).toFloat()
                            val y2 = targetPos.y - arrowLen * sin(angle + arrowAngle).toFloat()

                            val path = Path().apply {
                                moveTo(targetPos.x, targetPos.y)
                                lineTo(x1, y1)
                                lineTo(x2, y2)
                                close()
                            }
                            drawPath(path = path, color = tertiaryColor)

                            // Observer Node (P1)
                            drawCircle(color = primaryColor, radius = 9f, center = center)
                            drawCircle(color = Color.Black, radius = 4f, center = center)

                            // Target Node (P2)
                            drawCircle(color = errorColor, radius = 10f, center = targetPos)
                            drawCircle(color = Color.White, radius = 5f, center = targetPos)

                            // Labels
                            drawContext.canvas.nativeCanvas.apply {
                                val textPaint = android.graphics.Paint().apply {
                                    color = android.graphics.Color.WHITE
                                    textSize = 26f
                                    isFakeBoldText = true
                                }
                                textPaint.color = android.graphics.Color.GREEN
                                drawText("P1 [OBS]", center.x + 12f, center.y + 24f, textPaint)

                                textPaint.color = android.graphics.Color.YELLOW
                                drawText("P2 [TGT]", targetPos.x + 12f, targetPos.y - 12f, textPaint)

                                val midX = (center.x + targetPos.x) / 2f
                                val midY = (center.y + targetPos.y) / 2f
                                textPaint.color = android.graphics.Color.CYAN
                                textPaint.textSize = 24f
                                drawText(
                                    "${calcResult.formatDistance(DistanceUnit.KILOMETERS)} @ ${calcResult.bearingRounded}°",
                                    midX + 8f,
                                    midY - 8f,
                                    textPaint
                                )
                            }
                        } else {
                            drawCircle(color = primaryColor, radius = 6f, center = center)
                        }
                    }
                } else {
                    // OFFLINE TACTICAL MAP CANVAS (Renders cached map tiles & geodetic overlay)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        val p1Lat = calcResult?.point1?.latitude ?: 23.8103
                        val p1Lon = calcResult?.point1?.longitude ?: 90.4125
                        val p2Lat = calcResult?.point2?.latitude ?: p1Lat
                        val p2Lon = calcResult?.point2?.longitude ?: p1Lon

                        val centerLat = (p1Lat + p2Lat) / 2.0
                        val centerLon = (p1Lon + p2Lon) / 2.0

                        val centerTileX = OfflineMapManager.lonToTileX(centerLon, offlineZoom)
                        val centerTileY = OfflineMapManager.latToTileY(centerLat, offlineZoom)

                        // Draw 3x3 surrounding tiles around center
                        val tileSize = 256
                        val canvasCenterX = w / 2f
                        val canvasCenterY = h / 2f

                        var anyTileDrawn = false

                        for (dx in -1..1) {
                            for (dy in -1..1) {
                                val tx = centerTileX + dx
                                val ty = centerTileY + dy

                                val bmp = OfflineMapManager.getCachedTileBitmap(context, offlineZoom, tx, ty)
                                val posX = canvasCenterX + (dx * tileSize) - (tileSize / 2f)
                                val posY = canvasCenterY + (dy * tileSize) - (tileSize / 2f)

                                if (bmp != null) {
                                    anyTileDrawn = true
                                    val imageBitmap = bmp.asImageBitmap()
                                    drawImage(
                                        image = imageBitmap,
                                        dstOffset = IntOffset(posX.toInt(), posY.toInt()),
                                        dstSize = IntSize(tileSize, tileSize)
                                    )
                                } else {
                                    // Tactical grid tile placeholder
                                    drawRect(
                                        color = Color(0xFF0F172A),
                                        topLeft = Offset(posX, posY),
                                        size = androidx.compose.ui.geometry.Size(tileSize.toFloat(), tileSize.toFloat())
                                    )
                                    drawRect(
                                        color = Color(0xFF334155),
                                        topLeft = Offset(posX, posY),
                                        size = androidx.compose.ui.geometry.Size(tileSize.toFloat(), tileSize.toFloat()),
                                        style = Stroke(1f)
                                    )
                                }
                            }
                        }

                        // Tactical Grid lines & Coordinates
                        val gridStep = 80f
                        var gx = 0f
                        while (gx < w) {
                            drawLine(color = Color(0x3338BDF8), start = Offset(gx, 0f), end = Offset(gx, h), strokeWidth = 1f)
                            gx += gridStep
                        }
                        var gy = 0f
                        while (gy < h) {
                            drawLine(color = Color(0x3338BDF8), start = Offset(0f, gy), end = Offset(w, gy), strokeWidth = 1f)
                            gy += gridStep
                        }

                        // Project Points P1 & P2
                        if (calcResult != null) {
                            val p1Pos = Offset(w * 0.3f, h * 0.7f)
                            val p2Pos = Offset(w * 0.7f, h * 0.3f)

                            // Track Line
                            drawLine(
                                color = tertiaryColor,
                                start = p1Pos,
                                end = p2Pos,
                                strokeWidth = 3.5f,
                                cap = StrokeCap.Round
                            )

                            // Observer P1 Marker
                            drawCircle(color = primaryColor, radius = 10f, center = p1Pos)
                            drawCircle(color = Color.Black, radius = 5f, center = p1Pos)

                            // Target P2 Marker
                            drawCircle(color = errorColor, radius = 10f, center = p2Pos)
                            drawCircle(color = Color.White, radius = 5f, center = p2Pos)

                            drawContext.canvas.nativeCanvas.apply {
                                val p = android.graphics.Paint().apply {
                                    color = android.graphics.Color.WHITE
                                    textSize = 24f
                                    isFakeBoldText = true
                                    setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
                                }
                                p.color = android.graphics.Color.GREEN
                                drawText("SITE A (${"%.3f".format(p1Lat)}, ${"%.3f".format(p1Lon)})", p1Pos.x + 14f, p1Pos.y + 8f, p)

                                p.color = android.graphics.Color.RED
                                drawText("SITE B (${"%.3f".format(p2Lat)}, ${"%.3f".format(p2Lon)})", p2Pos.x - 120f, p2Pos.y - 14f, p)

                                p.color = android.graphics.Color.YELLOW
                                p.textSize = 22f
                                val midX = (p1Pos.x + p2Pos.x) / 2f
                                val midY = (p1Pos.y + p2Pos.y) / 2f
                                drawText("${calcResult.formatDistance(DistanceUnit.KILOMETERS)} @ ${calcResult.bearingRounded}°", midX + 8f, midY - 8f, p)
                            }
                        }

                        // Scale and Offline Status Tag
                        drawContext.canvas.nativeCanvas.apply {
                            val statusPaint = android.graphics.Paint().apply {
                                color = if (isOfflineCached) android.graphics.Color.GREEN else android.graphics.Color.CYAN
                                textSize = 22f
                                isFakeBoldText = true
                                setShadowLayer(3f, 1f, 1f, android.graphics.Color.BLACK)
                            }
                            val statusText = if (isOfflineCached) "⚡ OFFLINE MAP ACTIVE (CACHED TILES)" else "📡 TACTICAL GRID MAP"
                            drawText(statusText, 16f, 32f, statusPaint)

                            statusPaint.textSize = 18f
                            statusPaint.color = android.graphics.Color.LTGRAY
                            drawText("Center: ${"%.3f".format(centerLat)}°N, ${"%.3f".format(centerLon)}°E | Zoom: $offlineZoom", 16f, h - 16f, statusPaint)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Elevation and Coordinates stats bar
            if (calcResult != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(surfaceColor, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "P1 Elevation",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (p1Elevation != null) "${"%.1f".format(p1Elevation)} m" else "N/A",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Δ Elevation",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val delta = if (p1Elevation != null && p2Elevation != null) p2Elevation - p1Elevation else null
                        val deltaPrefix = if (delta != null && delta > 0) "+" else ""
                        Text(
                            text = if (delta != null) "$deltaPrefix${"%.1f".format(delta)} m" else "--",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = tertiaryColor
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "P2 Elevation",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (p2Elevation != null) "${"%.1f".format(p2Elevation)} m" else "N/A",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = secondaryColor
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Google Maps Launcher Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (calcResult != null) {
                            openGoogleMapsRoute(
                                context,
                                calcResult.point1.latitude,
                                calcResult.point1.longitude,
                                calcResult.point2.latitude,
                                calcResult.point2.longitude
                            )
                        } else {
                            Toast.makeText(context, "দয়া করে প্রথমে হিসাব করুন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("map_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = "Navigate in Google Maps", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Google Maps", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        if (calcResult != null) {
                            openSatelliteView(context, calcResult.point2.latitude, calcResult.point2.longitude)
                        } else {
                            Toast.makeText(context, "লোকেশন দিন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Map, contentDescription = "Satellite View", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Satellite Target", fontSize = 13.sp)
                }
            }
        }
    }
}

private fun openGoogleMapsRoute(context: Context, lat1: Double, lon1: Double, lat2: Double, lon2: Double) {
    try {
        val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=$lat1,$lon1&destination=$lat2,$lon2&travelmode=driving")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.apps.maps")
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            // Fallback to browser or any map app
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    } catch (_: Exception) {
        val webUri = Uri.parse("https://www.google.com/maps/dir/$lat1,$lon1/$lat2,$lon2")
        context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
    }
}

private fun openSatelliteView(context: Context, lat: Double, lon: Double) {
    try {
        val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon(Target)&z=16")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (_: Exception) {
        val webUri = Uri.parse("https://maps.google.com/?q=$lat,$lon&t=k")
        context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
    }
}
