package com.example

import com.example.data.model.CalculationResult
import com.example.data.model.DistanceUnit
import com.example.data.model.KmlExporter
import com.example.data.model.LosAnalysisResult
import com.example.data.model.LosCalculator
import com.example.data.model.NavigationCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testDistanceAndBearingCalculation() {
        // Dhaka (23.8103, 90.4125) to Rajshahi (24.3636, 88.6241)
        val lat1 = 23.8103
        val lon1 = 90.4125
        val lat2 = 24.3636
        val lon2 = 88.6241

        val result = NavigationCalculator.calculate(lat1, lon1, lat2, lon2, 19.0, 21.0)

        val km = result.distanceMeters / 1000.0
        assertTrue("Distance should be around 190 km, got $km", km in 170.0..210.0)
        assertTrue("Bearing should be WNW/NW, got ${result.bearingDegrees}", result.bearingDegrees in 270.0..330.0)

        val diff = kotlin.math.abs(result.backBearingDegrees - ((result.bearingDegrees + 180) % 360))
        assertTrue("Back bearing reciprocal check, got diff $diff", diff < 5.0)

        val expectedMils = ((result.bearingDegrees / 360.0) * 6400).toInt()
        assertEquals(expectedMils, result.bearingMils)
    }

    @Test
    fun testLineOfSightAndFresnelCalculation() {
        val clearLos = LosCalculator.calculateLineOfSight(
            distanceKm = 5.0,
            p1Elevation = 20.0,
            p1AntennaHeight = 15.0,
            p2Elevation = 20.0,
            p2AntennaHeight = 15.0,
            frequencyMhz = 5800.0
        )
        assertTrue("Short distance with 5.8GHz and 15m towers should be CLEAR", clearLos.isLosClear)
        assertEquals(LosAnalysisResult.StatusColor.CLEAR, clearLos.statusColorType)
        assertTrue(clearLos.clearanceMarginMeters > 0)

        val marginalLos = LosCalculator.calculateLineOfSight(
            distanceKm = 5.0,
            p1Elevation = 20.0,
            p1AntennaHeight = 15.0,
            p2Elevation = 20.0,
            p2AntennaHeight = 15.0,
            frequencyMhz = 400.0
        )
        assertEquals(LosAnalysisResult.StatusColor.MARGINAL, marginalLos.statusColorType)

        val longObstructed = LosCalculator.calculateLineOfSight(
            distanceKm = 50.0,
            p1Elevation = 10.0,
            p1AntennaHeight = 10.0,
            p2Elevation = 10.0,
            p2AntennaHeight = 10.0,
            frequencyMhz = 400.0
        )
        assertTrue("50 km with 10m towers should be obstructed by Earth curvature", !longObstructed.isLosClear)
        assertEquals(LosAnalysisResult.StatusColor.OBSTRUCTED, longObstructed.statusColorType)
        assertTrue("Earth bulge should be > 30m for 50km", longObstructed.earthCurvatureBulgeMeters > 30.0)
    }

    @Test
    fun testKmlExportGeneration() {
        val calc = NavigationCalculator.calculate(23.8103, 90.4125, 24.3636, 88.6241, 19.0, 21.0)
        val los = LosCalculator.calculateLineOfSight(190.0, 19.0, 30.0, 21.0, 30.0, 400.0)

        val kml = KmlExporter.generateKmlContent(
            calcResult = calc,
            p1Elevation = 19.0,
            p1AntennaHeight = 30.0,
            p2Elevation = 21.0,
            p2AntennaHeight = 30.0,
            frequencyMhz = 400.0,
            losResult = los
        )

        assertTrue("KML must contain kml tag", kml.contains("<kml xmlns=\"http://www.opengis.net/kml/2.2\""))
        assertTrue("KML must contain Terminal 1 placemark", kml.contains("Site A [Terminal 1]"))
        assertTrue("KML must contain Terminal 2 placemark", kml.contains("Site B [Terminal 2]"))
        assertTrue("KML must contain 3D Line of Sight Ray", kml.contains("<name>3D Line of Sight (LOS Ray)</name>"))
        assertTrue("KML must contain author credit", kml.contains("1618101 Cpl (Tech) Md Zakaria Alom, 3 Sigbn"))
    }

    @Test
    fun testCardinalDirectionHelper() {
        assertEquals("N", CalculationResult.getCardinalDirection(0.0))
        assertEquals("N", CalculationResult.getCardinalDirection(359.0))
        assertEquals("E", CalculationResult.getCardinalDirection(90.0))
        assertEquals("S", CalculationResult.getCardinalDirection(180.0))
        assertEquals("W", CalculationResult.getCardinalDirection(270.0))
        assertEquals("NE", CalculationResult.getCardinalDirection(45.0))
        assertEquals("SW", CalculationResult.getCardinalDirection(225.0))
    }

    @Test
    fun testUnitConversion() {
        val meters = 5000.0
        assertEquals(5.0, DistanceUnit.KILOMETERS.convertFromMeters(meters), 0.001)
        assertEquals(5000.0, DistanceUnit.METERS.convertFromMeters(meters), 0.001)
        assertEquals(3.10686, DistanceUnit.MILES.convertFromMeters(meters), 0.01)
        assertEquals(2.69978, DistanceUnit.NAUTICAL_MILES.convertFromMeters(meters), 0.01)
    }

    @Test
    fun testSlopeCalculation() {
        val (grade, angle) = NavigationCalculator.calculateSlope(1000.0, 100.0)
        assertEquals(10.0, grade, 0.01)
        assertTrue(angle > 5.0 && angle < 6.0)
    }

    @Test
    fun testOfflineMapBoundingBoxAndTiles() {
        // Dhaka coordinates
        val lat1 = 23.8103
        val lon1 = 90.4125
        val lat2 = 24.3636
        val lon2 = 88.6241

        val bbox = com.example.data.model.OfflineMapManager.calculateBoundingBox(lat1, lon1, lat2, lon2)
        assertTrue(bbox.contains(lat1, lon1))
        assertTrue(bbox.contains(lat2, lon2))
        assertTrue(bbox.minLat < 23.8103)
        assertTrue(bbox.maxLat > 24.3636)

        // Web Mercator tile coordinates test for Zoom 13
        val tileX = com.example.data.model.OfflineMapManager.lonToTileX(lon1, 13)
        val tileY = com.example.data.model.OfflineMapManager.latToTileY(lat1, 13)
        assertTrue("TileX should be positive for eastern hemisphere", tileX > 0)
        assertTrue("TileY should be positive for northern hemisphere", tileY > 0)

        val restoredLon = com.example.data.model.OfflineMapManager.tileXToLon(tileX, 13)
        assertTrue("Restored Lon should be close to original", kotlin.math.abs(restoredLon - lon1) < 0.1)
    }
}
